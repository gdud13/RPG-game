"""
Single-player text RPG: Reincarnated Adventurer
Run with: python main.py
"""

from game import Game


if __name__ == "__main__":
    Game().run()
