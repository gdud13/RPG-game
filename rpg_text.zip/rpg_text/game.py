import json
import os
import random
import builtins
from dataclasses import dataclass
from typing import Dict, List, Optional

RANKS = ["F", "E", "D", "C", "B", "A", "S"]

RANK_REQ = {
    "F": {"xp": 220, "quests": 5, "rep": 20},
    "E": {"xp": 1100, "quests": 18, "rep": 70},
    "D": {"xp": 2800, "quests": 38, "rep": 145},
    "C": {"xp": 6200, "quests": 72, "rep": 280},
    "B": {"xp": 10800, "quests": 105, "rep": 430},
    "A": {"xp": 17000, "quests": 145, "rep": 620},
}

CLASS_DATA = {
    "Swordsman": {
        "mods": {"max_hp": 30, "max_mp": 8, "str": 7, "int": -2, "def": 4, "agi": 2},
        "skills": {
            1: [{"name": "Bloodline Cut", "mp": 4, "pow": 1.45, "kind": "sword_bleed", "element": "neutral", "bleed_chance": 0.65, "bleed_turns": 2}],
            4: [{"name": "Rending Lunge", "mp": 6, "pow": 1.75, "kind": "sword_bleed", "element": "neutral", "bleed_chance": 0.75, "bleed_turns": 2}],
            7: [{"name": "Cross Vein Slash", "mp": 8, "pow": 2.05, "kind": "sword_bleed", "element": "neutral", "bleed_chance": 0.8, "bleed_turns": 3}],
            11: [{"name": "Hemorrhage Spiral", "mp": 11, "pow": 2.35, "kind": "sword_bleed", "element": "neutral", "bleed_chance": 0.9, "bleed_turns": 3}],
            15: [{"name": "Crimson Verdict", "mp": 14, "pow": 2.8, "kind": "sword_bleed", "element": "neutral", "bleed_chance": 1.0, "bleed_turns": 4}],
        },
    },
    "Mage": {
        "mods": {"max_hp": -8, "max_mp": 35, "str": -2, "int": 9, "def": -2, "agi": 2},
        "skills": {
            1: [{"name": "Arc Spark", "mp": 4, "pow": 1.3, "kind": "mag", "element": "arcane"}],
        },
    },
    "Path3": {
        "mods": {"max_hp": 0, "max_mp": 0, "str": 0, "int": 0, "def": 0, "agi": 0},
        "skills": {},
    },
}

NOVICE_SKILLS = {
    "Mage": [
        {"name": "Ember", "mp": 4, "pow": 1.2, "kind": "mag", "element": "fire"},
        {"name": "Frost Pebble", "mp": 4, "pow": 1.2, "kind": "mag", "element": "ice"},
        {"name": "Spark Needle", "mp": 5, "pow": 1.25, "kind": "mag", "element": "lightning"},
        {"name": "Stone Dart", "mp": 4, "pow": 1.2, "kind": "mag", "element": "earth"},
        {"name": "Gale Slice", "mp": 5, "pow": 1.28, "kind": "mag", "element": "wind"},
        {"name": "Mist Orb", "mp": 5, "pow": 1.3, "kind": "mag", "element": "water"},
        {"name": "Solar Pin", "mp": 6, "pow": 1.34, "kind": "mag", "element": "light"},
        {"name": "Lunar Lash", "mp": 6, "pow": 1.34, "kind": "mag", "element": "arcane"},
        {"name": "Thunder Lash", "mp": 6, "pow": 1.38, "kind": "mag", "element": "lightning"},
        {"name": "Cinder Shot", "mp": 6, "pow": 1.4, "kind": "mag", "element": "fire"},
    ],
}

PROFICIENT_SKILLS = {
    "Elementalist": [
        {"name": "Inferno Wheel", "mp": 10, "pow": 2.2, "kind": "mag", "element": "fire"},
        {"name": "Absolute Zero", "mp": 11, "pow": 2.25, "kind": "mag", "element": "ice"},
        {"name": "Volt Spear", "mp": 11, "pow": 2.3, "kind": "mag", "element": "lightning"},
        {"name": "Gaia Crush", "mp": 12, "pow": 2.35, "kind": "mag", "element": "earth"},
        {"name": "Tempest Fang", "mp": 12, "pow": 2.35, "kind": "mag", "element": "wind"},
        {"name": "Tidal Collapse", "mp": 12, "pow": 2.35, "kind": "mag", "element": "water"},
        {"name": "Solar Break", "mp": 13, "pow": 2.45, "kind": "mag", "element": "light"},
        {"name": "Prism Burst", "mp": 13, "pow": 2.5, "kind": "mag", "element": "arcane"},
        {"name": "Meteor Arc", "mp": 14, "pow": 2.6, "kind": "mag", "element": "fire"},
        {"name": "Cataclysm Field", "mp": 16, "pow": 2.75, "kind": "mag", "element": "arcane"},
    ],
    "Necromancer": [
        {"name": "Virulent Mist", "mp": 9, "pow": 1.8, "kind": "poison", "element": "poison"},
        {"name": "Soul Latch", "mp": 10, "pow": 1.85, "kind": "soul_stun", "element": "soul"},
        {"name": "Life Drain", "mp": 10, "pow": 1.9, "kind": "drain", "element": "dark"},
        {"name": "Raise Skeleton Guard", "mp": 11, "pow": 0.0, "kind": "skeleton_guard", "element": "dark"},
        {"name": "Grave Rot", "mp": 11, "pow": 2.0, "kind": "poison", "element": "dark"},
        {"name": "Death Bell", "mp": 12, "pow": 2.1, "kind": "soul_stun", "element": "soul"},
        {"name": "Blood Tithe", "mp": 12, "pow": 2.15, "kind": "drain", "element": "dark"},
        {"name": "Necrotic Lance", "mp": 13, "pow": 2.25, "kind": "mag", "element": "dark"},
        {"name": "Crypt Nova", "mp": 14, "pow": 2.35, "kind": "aoe_dark", "element": "dark"},
        {"name": "Soul Dominion", "mp": 16, "pow": 2.6, "kind": "soul_stun", "element": "soul"},
    ],
}

ITEMS = {
    "Potion": {"t": "con", "heal": 40, "price": 25},
    "Mana Potion": {"t": "con", "mp": 25, "price": 30},
    "Jerky": {"t": "con", "heal": 20, "mp": 10, "price": 15},
    "Iron Sword": {"t": "eq", "slot": "weapon", "mods": {"str": 3}, "price": 80},
    "Oak Staff": {"t": "eq", "slot": "weapon", "mods": {"int": 3}, "price": 80},
    "Leather Armor": {"t": "eq", "slot": "armor", "mods": {"def": 2}, "price": 70},
}

ENEMIES = {
    "Slime": {"hp": 45, "mp": 0, "str": 8, "int": 2, "def": 3, "agi": 4, "xp": 28, "gold": 18, "weak": ["fire"], "dmg_mult": 1.5, "flesh": False},
    "Wolf": {"hp": 72, "mp": 0, "str": 13, "int": 2, "def": 5, "agi": 11, "xp": 54, "gold": 30, "weak": ["fire"], "flesh": True},
    "Goblin": {"hp": 92, "mp": 0, "str": 15, "int": 3, "def": 7, "agi": 9, "xp": 70, "gold": 40, "weak": ["fire"], "flesh": True},
    "Frost Spider": {"hp": 106, "mp": 16, "str": 14, "int": 10, "def": 8, "agi": 15, "xp": 88, "gold": 54, "weak": ["fire"]},
    "Lizardman": {"hp": 126, "mp": 4, "str": 18, "int": 5, "def": 10, "agi": 12, "xp": 102, "gold": 62, "weak": ["ice"], "flesh": True},
    "Cultist": {"hp": 128, "mp": 30, "str": 17, "int": 16, "def": 9, "agi": 10, "xp": 115, "gold": 68, "weak": ["ice"], "flesh": True},
    "Bandit": {"hp": 165, "mp": 12, "str": 24, "int": 8, "def": 13, "agi": 11, "xp": 165, "gold": 95, "weak": ["fire"], "flesh": True},
    "Harpy": {"hp": 172, "mp": 18, "str": 22, "int": 10, "def": 12, "agi": 18, "xp": 176, "gold": 98, "weak": ["lightning"]},
    "Warlock": {"hp": 188, "mp": 42, "str": 15, "int": 24, "def": 13, "agi": 12, "xp": 205, "gold": 118, "weak": ["arcane"], "flesh": True},
    "Wraith": {"hp": 245, "mp": 40, "str": 20, "int": 27, "def": 16, "agi": 15, "xp": 265, "gold": 145, "weak": ["lightning", "arcane"], "flesh": False, "aoe": True},
    "Stone Golem": {"hp": 320, "mp": 0, "str": 30, "int": 4, "def": 26, "agi": 5, "xp": 335, "gold": 210, "weak": ["arcane", "lightning"], "flesh": False},
    "Minotaur": {"hp": 340, "mp": 0, "str": 35, "int": 6, "def": 20, "agi": 9, "xp": 355, "gold": 225, "weak": ["ice"], "flesh": True},
    "Ogre": {"hp": 360, "mp": 0, "str": 34, "int": 5, "def": 22, "agi": 8, "xp": 390, "gold": 240, "weak": ["fire"], "flesh": True},
    "Dread Revenant": {"hp": 420, "mp": 55, "str": 33, "int": 35, "def": 24, "agi": 16, "xp": 510, "gold": 320, "weak": ["lightning", "fire"], "flesh": False, "aoe": True},
    "Hex Priest": {"hp": 460, "mp": 70, "str": 26, "int": 38, "def": 23, "agi": 14, "xp": 560, "gold": 335, "weak": ["lightning", "arcane"], "flesh": True, "aoe": True},
    "Ash Drake": {"hp": 540, "mp": 35, "str": 41, "int": 25, "def": 28, "agi": 14, "xp": 650, "gold": 420, "weak": ["ice"], "flesh": True, "aoe": True},
    "Chimera": {"hp": 600, "mp": 24, "str": 44, "int": 22, "def": 30, "agi": 17, "xp": 720, "gold": 470, "weak": ["ice", "arcane"], "flesh": True, "aoe": True},
    "Assassin": {"hp": 185, "mp": 12, "str": 27, "int": 10, "def": 14, "agi": 20, "xp": 180, "gold": 0, "weak": ["lightning"], "flesh": True},
}

QUESTS = [
    {"name": "Clear Slime Nest", "type": "Combat", "min": "F", "enemy": "Slime", "gold": 35, "xp": 45, "rep": 6, "cd": 1},
    {"name": "Medicinal Herb Run", "type": "Gathering", "min": "F", "gold": 30, "xp": 35, "rep": 5, "cd": 1},
    {"name": "Drive Off Hungry Wolves", "type": "Combat", "min": "F", "enemy": "Wolf", "gold": 42, "xp": 52, "rep": 6, "cd": 1},
    {"name": "Merchant Escort", "type": "Escort", "min": "E", "enemy": "Goblin", "gold": 60, "xp": 70, "rep": 10, "cd": 2},
    {"name": "Clear Frost Burrow", "type": "Combat", "min": "E", "enemy": "Frost Spider", "gold": 74, "xp": 90, "rep": 10, "cd": 2},
    {"name": "Swamp Patrol", "type": "Combat", "min": "E", "enemy": "Lizardman", "gold": 76, "xp": 92, "rep": 10, "cd": 2},
    {"name": "Put Down Forest Cult", "type": "Combat", "min": "E", "enemy": "Cultist", "gold": 78, "xp": 95, "rep": 11, "cd": 2},
    {"name": "Ruined Chapel Investigation", "type": "Investigation", "min": "D", "enemy": "Wraith", "gold": 95, "xp": 110, "rep": 14, "cd": 2},
    {"name": "Silence Cliff Harpies", "type": "Combat", "min": "D", "enemy": "Harpy", "gold": 108, "xp": 126, "rep": 15, "cd": 2},
    {"name": "Break Smuggler Circle", "type": "Combat", "min": "D", "enemy": "Bandit", "gold": 110, "xp": 130, "rep": 15, "cd": 2},
    {"name": "Cinder Sigil Hunt", "type": "Combat", "min": "C", "enemy": "Warlock", "gold": 140, "xp": 176, "rep": 18, "cd": 3},
    {"name": "Subdue Highway Bandits", "type": "Combat", "min": "C", "enemy": "Bandit", "gold": 120, "xp": 140, "rep": 17, "cd": 3},
    {"name": "Cavern Core Purge", "type": "Combat", "min": "C", "enemy": "Stone Golem", "gold": 165, "xp": 220, "rep": 21, "cd": 3},
    {"name": "Labyrinth Hornbreak", "type": "Combat", "min": "B", "enemy": "Minotaur", "gold": 210, "xp": 265, "rep": 25, "cd": 4},
    {"name": "Ogre Hunt", "type": "Combat", "min": "B", "enemy": "Ogre", "gold": 175, "xp": 190, "rep": 22, "cd": 3},
    {"name": "Silence the Revenant", "type": "Combat", "min": "B", "enemy": "Dread Revenant", "gold": 230, "xp": 300, "rep": 28, "cd": 4},
    {"name": "Cathedral Hex Purge", "type": "Combat", "min": "A", "enemy": "Hex Priest", "gold": 315, "xp": 400, "rep": 34, "cd": 4},
    {"name": "Ash Drake Suppression", "type": "Combat", "min": "A", "enemy": "Ash Drake", "gold": 340, "xp": 420, "rep": 36, "cd": 4},
    {"name": "Chimera Den Extermination", "type": "Combat", "min": "A", "enemy": "Chimera", "gold": 380, "xp": 470, "rep": 39, "cd": 5},
]

SPECIAL_REQUEST_NAME = "Special Request: Black-Banner Camp"

KARMA_QUESTS = [
    {
        "name": "Karma Quest: Midnight Contract",
        "type": "Combat",
        "min": "E",
        "enemy": "Assassin",
        "gold": 145,
        "xp": 150,
        "rep": 6,
        "cd": 3,
        "karma_min": 0,
        "karma_max": 3,
        "karma_tag": "low",
    },
    {
        "name": "Karma Quest: Broken Oaths Mediation",
        "type": "Investigation",
        "min": "E",
        "enemy": "Bandit",
        "gold": 100,
        "xp": 130,
        "rep": 10,
        "cd": 3,
        "karma_min": 4,
        "karma_max": 7,
        "karma_tag": "neutral",
    },
    {
        "name": "Karma Quest: Sanctuary Vigil",
        "type": "Combat",
        "min": "D",
        "enemy": "Wraith",
        "gold": 125,
        "xp": 190,
        "rep": 16,
        "cd": 4,
        "karma_min": 8,
        "karma_max": 10,
        "karma_tag": "high",
    },
]

SPECIAL_LIEUTENANTS = [
    {"name": "Lieutenant Kael", "hp": 150, "mp": 0, "str": 11, "int": 3, "def": 11, "agi": 10, "xp": 55, "gold": 32, "weak": ["fire"]},
    {"name": "Lieutenant Varo", "hp": 138, "mp": 14, "str": 10, "int": 14, "def": 10, "agi": 11, "xp": 60, "gold": 35, "weak": ["lightning"]},
    {"name": "Lieutenant Myra", "hp": 145, "mp": 6, "str": 12, "int": 8, "def": 12, "agi": 14, "xp": 62, "gold": 36, "weak": ["ice"]},
    {"name": "Lieutenant Dren", "hp": 168, "mp": 0, "str": 12, "int": 4, "def": 15, "agi": 9, "xp": 66, "gold": 40, "weak": ["arcane"]},
    {"name": "Lieutenant Serik", "hp": 158, "mp": 10, "str": 12, "int": 10, "def": 13, "agi": 12, "xp": 70, "gold": 42, "weak": ["fire", "lightning"]},
]


def rix(rank: str) -> int:
    return RANKS.index(rank)


def ask(max_n: int) -> int:
    while True:
        x = input("> ").strip()
        if x.isdigit() and 1 <= int(x) <= max_n:
            return int(x)
        print("Invalid input.")


@dataclass
class Stats:
    max_hp: builtins.int
    max_mp: builtins.int
    str: builtins.int
    int: builtins.int
    defn: builtins.int
    agi: builtins.int

    def as_dict(self):
        return {"max_hp": self.max_hp, "max_mp": self.max_mp, "str": self.str, "int": self.int, "def": self.defn, "agi": self.agi}

    @staticmethod
    def from_dict(d):
        return Stats(d["max_hp"], d["max_mp"], d["str"], d["int"], d["def"], d["agi"])


class Player:
    def __init__(self, name: str):
        self.name = name
        self.level = 1
        self.rank = "F"
        self.exp = 0
        self.gold = 60
        self.rep = 0
        self.class_name: Optional[str] = None
        self.subclass_name: Optional[str] = None
        self.quests_done = 0
        self.path_choice: Optional[str] = None
        self.karma = 5
        self.novice_training = 0
        self.proficient_training = 0
        self.base = Stats(100, 15, 10, 8, 8, 8)
        self.skills: List[Dict] = []
        self.items: Dict[str, int] = {"Potion": 2, "Jerky": 1}
        self.equip: Dict[str, Optional[str]] = {"weapon": None, "armor": None}
        self.stats = self.calc_stats()
        self.hp = self.stats.max_hp
        self.mp = self.stats.max_mp
        self.guard = 0
    def calc_stats(self) -> Stats:
        mods = {"max_hp": 0, "max_mp": 0, "str": 0, "int": 0, "def": 0, "agi": 0}
        if self.class_name:
            for k, v in CLASS_DATA[self.class_name]["mods"].items():
                mods[k] += v
        for it in self.equip.values():
            if it and it in ITEMS:
                for k, v in ITEMS[it].get("mods", {}).items():
                    mods[k] += v
        return Stats(
            self.base.max_hp + mods["max_hp"] + (self.level - 1) * 8,
            self.base.max_mp + mods["max_mp"] + (self.level - 1) * 4,
            self.base.str + mods["str"] + (self.level - 1) * 2,
            self.base.int + mods["int"] + (self.level - 1) * 2,
            self.base.defn + mods["def"] + (self.level - 1) * 2,
            self.base.agi + mods["agi"] + (self.level - 1),
        )

    def refresh(self, full=False):
        self.stats = self.calc_stats()
        if full:
            self.hp = self.stats.max_hp
            self.mp = self.stats.max_mp
        else:
            self.hp = min(self.hp, self.stats.max_hp)
            self.mp = min(self.mp, self.stats.max_mp)

    def need_xp(self):
        return int((80 + (self.level - 1) * 35) * 1.7)

    def total_xp(self):
        t = self.exp
        for l in range(1, self.level):
            t += int((80 + (l - 1) * 35) * 1.7)
        return t

    def add_karma(self, n: int):
        self.karma = max(0, min(10, self.karma + n))

    def crit_chance(self):
        if self.class_name == "Swordsman":
            return min(0.55, 0.12 + (self.level - 1) * 0.015)
        return 0.05

    def gain_xp(self, n: int):
        self.exp += n
        while self.exp >= self.need_xp():
            self.exp -= self.need_xp()
            self.level += 1
            self.refresh(full=True)
            print(f"\n>> Level up! Now level {self.level}")
            self.unlock_skills()

    def unlock_skills(self):
        if not self.class_name:
            return
        for lvl, skills in CLASS_DATA[self.class_name]["skills"].items():
            if lvl <= self.level:
                for s in skills:
                    if not any(x["name"] == s["name"] for x in self.skills):
                        self.skills.append(s)
                        print(f"   Learned: {s['name']}")

    def choose_class(self, cname: str):
        self.class_name = cname
        self.subclass_name = None
        self.skills = []
        self.refresh(full=True)
        self.unlock_skills()

    def choose_subclass(self, sname: str):
        if self.class_name == "Mage" and self.level >= 20 and sname in PROFICIENT_SKILLS:
            self.subclass_name = sname
            self.proficient_training = 0
            return True
        return False

    def try_rank_up(self):
        if self.rank == "S":
            return 0
        gained = 0
        while self.rank != "S":
            req = RANK_REQ.get(self.rank)
            if not req:
                break
            if not (self.total_xp() >= req["xp"] and self.quests_done >= req["quests"] and self.rep >= req["rep"]):
                break
            self.rank = RANKS[rix(self.rank) + 1]
            print(f"\n>> Promoted to {self.rank}-Rank!")
            gained += 1
        return gained

    def requirements_for_next_rank(self):
        if self.rank == "S":
            return None
        req = RANK_REQ[self.rank]
        return {
            "target": RANKS[rix(self.rank) + 1],
            "xp": (self.total_xp(), req["xp"]),
            "quests": (self.quests_done, req["quests"]),
            "rep": (self.rep, req["rep"]),
        }

    def can_train_novice(self):
        self.novice_training = max(0, min(20, self.novice_training))
        if self.class_name not in NOVICE_SKILLS:
            return False
        unlearned = [
            s for s in NOVICE_SKILLS[self.class_name]
            if not any(k["name"] == s["name"] for k in self.skills)
        ]
        return self.gold >= 50 and self.novice_training < 20 and len(unlearned) > 0

    def train_novice(self):
        self.novice_training = max(0, min(20, self.novice_training))
        if not self.can_train_novice():
            return False
        self.gold -= 50
        self.novice_training = min(20, self.novice_training + 1)
        return True

    def learn_novice_spell(self, spell_name: str):
        self.novice_training = max(0, min(20, self.novice_training))
        if self.class_name not in NOVICE_SKILLS or self.novice_training < 20:
            return False
        for s in NOVICE_SKILLS[self.class_name]:
            if s["name"] == spell_name and not any(x["name"] == s["name"] for x in self.skills):
                self.skills.append(dict(s))
                self.novice_training = max(0, self.novice_training - 20)
                return True
        return False

    def can_train_proficient(self):
        self.proficient_training = max(0, min(8, self.proficient_training))
        if self.class_name != "Mage" or not self.subclass_name:
            return False
        if self.subclass_name not in PROFICIENT_SKILLS or self.level < 20:
            return False
        unlearned = [
            s for s in PROFICIENT_SKILLS[self.subclass_name]
            if not any(k["name"] == s["name"] for k in self.skills)
        ]
        return self.gold >= 90 and self.proficient_training < 8 and len(unlearned) > 0

    def train_proficient(self):
        self.proficient_training = max(0, min(8, self.proficient_training))
        if not self.can_train_proficient():
            return False
        self.gold -= 90
        self.proficient_training = min(8, self.proficient_training + 1)
        return True

    def learn_proficient_spell(self, spell_name: str):
        self.proficient_training = max(0, min(8, self.proficient_training))
        key = self.subclass_name if self.class_name == "Mage" else self.class_name
        if key not in PROFICIENT_SKILLS or self.proficient_training < 8:
            return False
        for s in PROFICIENT_SKILLS[key]:
            if s["name"] == spell_name and not any(x["name"] == s["name"] for x in self.skills):
                self.skills.append(dict(s))
                self.proficient_training = max(0, self.proficient_training - 8)
                return True
        return False

    def estimated_skill_damage(self, skill: Dict):
        if skill["kind"] in ["buff", "skeleton_guard"]:
            return 0
        stat = self.stats.int if self.class_name == "Mage" else self.stats.str
        return max(1, int(stat * skill["pow"]))

    def to_dict(self):
        return {
            "name": self.name, "level": self.level, "rank": self.rank, "exp": self.exp,
            "gold": self.gold, "rep": self.rep, "class_name": self.class_name,
            "subclass_name": self.subclass_name,
            "quests_done": self.quests_done, "path_choice": self.path_choice,
            "karma": self.karma,
            "novice_training": self.novice_training, "proficient_training": self.proficient_training,
            "base": self.base.as_dict(), "skills": self.skills,
            "items": self.items, "equip": self.equip, "hp": self.hp, "mp": self.mp,
        }

    @staticmethod
    def from_dict(d):
        p = Player(d["name"])
        p.level = d["level"]; p.rank = d["rank"]; p.exp = d["exp"]
        p.gold = d["gold"]; p.rep = d["rep"]; p.class_name = d["class_name"]
        if p.class_name == "Knight":
            p.class_name = "Swordsman"
        if p.class_name == "Necromancer":
            p.class_name = "Mage"
            p.subclass_name = "Necromancer"
        else:
            p.subclass_name = d.get("subclass_name")
        p.quests_done = d["quests_done"]; p.path_choice = d.get("path_choice")
        p.karma = d.get("karma", 5)
        p.novice_training = max(0, min(20, d.get("novice_training", 0)))
        p.proficient_training = max(0, min(8, d.get("proficient_training", 0)))
        p.base = Stats.from_dict(d["base"]); p.skills = d.get("skills", [])
        p.items = d.get("items", {}); p.equip = d.get("equip", {"weapon": None, "armor": None})
        p.refresh(full=True)
        p.hp = min(d.get("hp", p.stats.max_hp), p.stats.max_hp)
        p.mp = min(d.get("mp", p.stats.max_mp), p.stats.max_mp)
        return p


class Combat:
    @staticmethod
    def dmg(att: int, de: int, mult: float):
        return max(1, int(att * mult - de * 0.45) + random.randint(-3, 5))

    @staticmethod
    def elemental_multiplier(enemy: Dict, skill: Dict):
        el = skill.get("element")
        weak = enemy.get("weak", [])
        return 1.35 if el and el in weak else 1.0

    @staticmethod
    def run_custom(p: Player, enemy_name: str, enemy_data: Dict) -> bool:
        return Combat._run_with_enemy(p, enemy_name, enemy_data.copy())

    @staticmethod
    def run(p: Player, enemy_name: str) -> bool:
        return Combat._run_with_enemy(p, enemy_name, ENEMIES[enemy_name].copy())

    @staticmethod
    def _run_with_enemy(p: Player, enemy_name: str, e: Dict) -> bool:
        # Global tuning pass: enemies are sturdier across the board.
        if not e.get("_scaled"):
            e["hp"] = max(1, int(e["hp"] * 1.2))
            e["def"] = max(1, int(e["def"] * 1.1))
            e["_scaled"] = True
        ehp, emp = e["hp"], e["mp"]
        bleed_turns, bleed_dmg = 0, 0
        poison_turns, poison_dmg = 0, 0
        stun_turns = 0
        skeleton_guard_hp = 0
        print(f"\nCombat: {p.name} vs {enemy_name}")
        while p.hp > 0 and ehp > 0:
            if bleed_turns > 0 and e.get("flesh", False):
                ehp = max(0, ehp - bleed_dmg)
                bleed_turns -= 1
                print(f"{enemy_name} bleeds for {bleed_dmg}.")
            if poison_turns > 0:
                ehp = max(0, ehp - poison_dmg)
                poison_turns -= 1
                print(f"{enemy_name} suffers poison for {poison_dmg}.")
            if ehp <= 0:
                break
            print(f"\n{p.name} HP {p.hp}/{p.stats.max_hp} MP {p.mp}/{p.stats.max_mp}")
            print(f"{enemy_name} HP {ehp}/{e['hp']}")
            if skeleton_guard_hp > 0:
                print(f"Skeleton Guard HP {skeleton_guard_hp}/50")
            print("1. Attack\n2. Skill\n3. Item\n4. Defend\n5. Flee")
            c = ask(5)
            if c == 1:
                d = Combat.dmg(p.stats.str, e["def"], 1.0)
                if p.class_name == "Swordsman" and random.random() < p.crit_chance():
                    d *= 2
                    print("Critical hit!")
                ehp = max(0, ehp - d)
                print(f"You hit for {d}.")
            elif c == 2:
                if not p.skills:
                    print("No skills yet.")
                else:
                    for i, s in enumerate(p.skills, 1):
                        print(f"{i}. {s['name']} (MP {s['mp']})")
                    s = p.skills[ask(len(p.skills)) - 1]
                    if p.mp < s["mp"]:
                        print("Not enough MP.")
                    else:
                        p.mp -= s["mp"]
                        stat = p.stats.int if p.class_name == "Mage" else p.stats.str
                        if s["kind"] == "buff":
                            p.guard += 5
                            print("Defense boosted.")
                            d = 0
                        elif s["kind"] == "skeleton_guard":
                            skeleton_guard_hp = 50
                            print("Skeleton guard rises and shields you.")
                            d = 0
                        else:
                            d = Combat.dmg(stat, e["def"], s["pow"])
                            if p.class_name == "Swordsman" and s["kind"] == "sword_bleed" and random.random() < p.crit_chance():
                                d *= 2
                                print("Critical hit!")
                            if Combat.elemental_multiplier(e, s) > 1.0:
                                d = int(d * Combat.elemental_multiplier(e, s))
                                print("Elemental weakness exploited!")
                            ehp = max(0, ehp - d)
                            print(f"{s['name']} deals {d}.")
                        if s["kind"] == "sword_bleed" and e.get("flesh", False):
                            if random.random() < s.get("bleed_chance", 0.7):
                                bleed_turns = max(bleed_turns, s.get("bleed_turns", 2))
                                bleed_dmg = max(bleed_dmg, max(3, int(d * 0.22)))
                                print("Bleed inflicted.")
                        if s["kind"] == "poison":
                            poison_turns = max(poison_turns, 3)
                            poison_dmg = max(poison_dmg, max(4, int(d * 0.2)))
                            print("Poison applied.")
                        if s["kind"] == "soul_stun" and random.random() < 0.9:
                            stun_turns = max(stun_turns, 1)
                            print("Soul lock! Enemy is stunned.")
                        if s["kind"] == "drain":
                            h = max(1, int(d * 0.1)); p.hp = min(p.stats.max_hp, p.hp + h); print(f"Drain heals {h}.")
                        if s["kind"] == "summon":
                            b = random.randint(4, 12); ehp = max(0, ehp - b); print(f"Skeleton hits for {b}.")
            elif c == 3:
                con = [k for k, q in p.items.items() if q > 0 and ITEMS.get(k, {}).get("t") == "con"]
                if not con:
                    print("No consumables.")
                else:
                    for i, it in enumerate(con, 1):
                        print(f"{i}. {it} x{p.items[it]}")
                    it = con[ask(len(con)) - 1]
                    p.items[it] -= 1
                    if p.items[it] <= 0:
                        del p.items[it]
                    data = ITEMS[it]
                    if "heal" in data:
                        p.hp = min(p.stats.max_hp, p.hp + data["heal"]); print(f"+{data['heal']} HP")
                    if "mp" in data:
                        p.mp = min(p.stats.max_mp, p.mp + data["mp"]); print(f"+{data['mp']} MP")
            elif c == 4:
                p.guard = 6
                print("You defend.")
            else:
                chance = max(0.05, min(0.9, 0.28 + (p.stats.agi - e["agi"]) * 0.03))
                if random.random() < chance:
                    print("Escaped.")
                    return False
                print("Could not flee.")
            if ehp > 0:
                if stun_turns > 0:
                    stun_turns -= 1
                    print(f"{enemy_name} is stunned and misses a turn.")
                    continue
                if emp >= 8 and e["int"] > e["str"] and random.random() < 0.45:
                    emp -= 8
                    d = Combat.dmg(e["int"] + 3, p.stats.defn + p.guard, 1.2)
                    d = int(d * 1.3)
                    d = int(d * e.get("dmg_mult", 1.0))
                    print(f"{enemy_name} casts for {d}.")
                else:
                    d = Combat.dmg(e["str"], p.stats.defn + p.guard, 1.0)
                    d = int(d * 1.3)
                    d = int(d * e.get("dmg_mult", 1.0))
                    print(f"{enemy_name} attacks for {d}.")
                if random.random() < 0.12:
                    d = int(d * 1.35)
                    print(f"{enemy_name} lands a critical hit!")
                if skeleton_guard_hp > 0 and not e.get("aoe", False):
                    skeleton_guard_hp = max(0, skeleton_guard_hp - d)
                    print(f"Skeleton guard tanks {d} damage.")
                    if skeleton_guard_hp <= 0:
                        print("Skeleton guard crumbles.")
                else:
                    p.hp = max(0, p.hp - d)
                p.guard = 0

        if p.hp > 0:
            p.gain_xp(e["xp"])
            p.gold += e["gold"]
            print(f"Victory! +{e['xp']} XP, +{e['gold']} Gold")
            return True

        print("Defeat. Guild medics rescue you. -25 Gold")
        p.gold = max(0, p.gold - 25)
        p.hp = max(1, p.stats.max_hp // 2)
        p.mp = max(0, p.stats.max_mp // 2)
        return False


class Game:
    SAVE_FILE = "savegame.json"

    def __init__(self):
        self.p: Optional[Player] = None
        self.day = 1
        self.cooldowns: Dict[str, int] = {}
        self.special_state = "offered"
        self.special_round = 0
        self.running = True

    def _player(self) -> Player:
        if self.p is None:
            raise RuntimeError("Player is not initialized.")
        return self.p

    def run(self):
        print("\n=== Reincarnated Guild Chronicle ===")
        print("You awaken in the Adventurers Guild infirmary with no memories.")
        print("An F-Rank tag is your only proof you exist in this world.\n")
        print("1. New Game\n2. Load Game\n3. Quit")
        t = ask(3)
        if t == 1:
            self.new_game()
        elif t == 2:
            if not self.load_game():
                print("No save found. Starting new game.")
                self.new_game()
        else:
            return

        while self.running:
            self.main_menu()

    def new_game(self):
        name = input("Enter your name: ").strip() or "Nameless"
        self.p = Player(name)
        print("\nReceptionist: 'Welcome to the guild. Survive first, ask questions later.'")

    def save_game(self):
        p = self._player()
        data = {
            "player": p.to_dict(),
            "day": self.day,
            "cooldowns": self.cooldowns,
            "special_state": self.special_state,
            "special_round": self.special_round,
        }
        with open(self.SAVE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print("Game saved.")

    def load_game(self) -> bool:
        if not os.path.exists(self.SAVE_FILE):
            return False
        with open(self.SAVE_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        self.p = Player.from_dict(d["player"])
        self.day = d.get("day", 1)
        self.cooldowns = d.get("cooldowns", {})
        self.special_state = d.get("special_state", "locked")
        self.special_round = d.get("special_round", 0)
        print(f"Loaded {self.p.name} (Day {self.day})")
        return True

    def main_menu(self):
        p = self._player()
        print(f"\n--- Day {self.day} | {p.name} Lv{p.level} {p.rank}-Rank ---")
        print(f"HP {p.hp}/{p.stats.max_hp} MP {p.mp}/{p.stats.max_mp} | Gold {p.gold} | Rep {p.rep}")
        print(f"Class: {p.class_name or 'Unchosen'} | Quests: {p.quests_done}")
        print("1. Visit Guild Hall\n2. Character\n3. Inventory\n4. Rest\n5. Save\n6. Quit")
        c = ask(6)
        if c == 1:
            self.guild_hall()
        elif c == 2:
            self.show_char()
        elif c == 3:
            self.inventory_menu()
        elif c == 4:
            self.rest()
        elif c == 5:
            self.save_game()
        else:
            self.running = False

    def guild_hall(self):
        p = self._player()
        while True:
            print("\n=== Guild Hall ===")
            print("1. Accept Mission\n2. Promotion Check\n3. Shop\n4. Class Mentor\n5. Back")
            c = ask(5)
            if c == 1:
                self.mission_board()
            elif c == 2:
                gained = p.try_rank_up()
                if gained == 0:
                    nxt = p.requirements_for_next_rank()
                    if nxt:
                        print(f"Next rank: {nxt['target']}")
                        print(f"XP {nxt['xp'][0]}/{nxt['xp'][1]} | Quests {nxt['quests'][0]}/{nxt['quests'][1]} | Rep {nxt['rep'][0]}/{nxt['rep'][1]}")
                    else:
                        print("Already at max rank.")
                if p.rank == "A" and not p.path_choice:
                    print("\nGuildmaster: 'Choose your path.'")
                    print("1. Elite Adventurer\n2. Guild Manager")
                    p.path_choice = "Elite Adventurer" if ask(2) == 1 else "Guild Manager"
                    print(f"Path chosen: {p.path_choice}")
            elif c == 3:
                self.shop()
            elif c == 4:
                self.class_mentor()
            else:
                break

    def special_request(self):
        p = self._player()
        if p.level < 5:
            print("Special request unlocks at level 5.")
            return
        if self.special_state == "locked":
            print("No special request is available yet.")
            return
        if self.special_state == "done":
            print("Special request already resolved.")
            return
        if self.special_state == "twist":
            print("\nThe last bandit chief drops his blade and offers all stolen coin for mercy.")
            print("1. Show mercy, take coin, and drive them out")
            print("2. Execute them and return the stolen money to Guildmaster Orin")
            if p.karma >= 8:
                print("3. High-karma parley: recruit them into supervised labor service")
            c = ask(3 if p.karma >= 8 else 2)
            if p.karma >= 8 and c == 3:
                p.add_karma(1)
                p.rep += 30
                p.gold += 180
                p.gain_xp(360)
                print("Your reputation opens a third path. The camp disbands under guild supervision.")
            elif c == 1:
                p.add_karma(1)
                p.gold += 320
                p.gain_xp(320)
                print("Mercy chosen. You take reparations and send them away. Karma +1.")
            else:
                p.rep += 18
                p.gold += 180
                p.gain_xp(340)
                print("Justice by steel. You return the stolen funds to Orin.")
            p.quests_done += 1
            self.special_state = "done"
            return

        print(f"Black-Banner Camp assault: lieutenant {self.special_round}/5")
        foe = dict(SPECIAL_LIEUTENANTS[self.special_round - 1])
        name = foe.pop("name")
        ok = Combat.run_custom(p, name, foe)
        if not ok:
            print("Assault failed. Regroup and try again.")
            return
        self.special_round += 1
        if self.special_round > 5:
            self.special_state = "twist"
            print("The camp falls. But in the command tent, something is very wrong...")

    def mission_board(self):
        p = self._player()
        available = []
        for q in QUESTS:
            if rix(p.rank) < rix(q["min"]):
                continue
            if q["name"] in self.cooldowns:
                continue
            if p.class_name == "Mage" and p.subclass_name == "Necromancer" and q["type"] == "Escort":
                continue
            available.append(q)
        for q in KARMA_QUESTS:
            if rix(p.rank) < rix(q["min"]):
                continue
            if q["name"] in self.cooldowns:
                continue
            if p.karma < q["karma_min"] or p.karma > q["karma_max"]:
                continue
            available.append(q)
        if p.level >= 5 and self.special_state in ["offered", "active", "twist"]:
            available.append({
                "name": SPECIAL_REQUEST_NAME,
                "type": "Special",
                "min": "Any",
                "gold": 0,
                "xp": 0,
                "rep": 0,
                "cd": 0,
            })
        if not available:
            print("No missions available.")
            return
        print("\nMissions:")
        for i, q in enumerate(available, 1):
            karma_label = ""
            if "karma_tag" in q:
                karma_label = f" | Karma Route: {q['karma_tag']}"
            print(f"{i}. [{q['type']}] {q['name']} ({q['min']}+) -> XP {q['xp']}, Gold {q['gold']}, Rep {q['rep']}{karma_label}")
        print(f"{len(available)+1}. Back")
        s = ask(len(available) + 1)
        if s == len(available) + 1:
            return
        self.run_quest(available[s - 1])

    def run_quest(self, q):
        p = self._player()
        print(f"\nMission accepted: {q['name']}")
        if q["type"] == "Special":
            if self.special_state == "offered":
                self.special_state = "active"
                self.special_round = 1
                print("Orin: 'Five lieutenants hold Black-Banner Camp. Bring it down.'")
            self.special_request()
            return
        ok = False
        if q["type"] == "Combat":
            ok = Combat.run(p, q["enemy"])
        elif q["type"] == "Gathering":
            chance = max(0.2, min(0.9, 0.55 + (p.stats.int + p.stats.agi - 14) * 0.015))
            ok = random.random() < chance
            print("You gather herbs in deep woods." if ok else "You lose the trail and return empty-handed.")
            if ok and random.random() < 0.3:
                p.items["Potion"] = p.items.get("Potion", 0) + 1
                print("Found Potion.")
        elif q["type"] == "Escort":
            if p.class_name == "Mage" and p.subclass_name == "Necromancer":
                print("Client rejects your dark aura.")
                ok = False
            else:
                ok = Combat.run(p, q["enemy"])
        else:
            print("Whispers fill the ruined chapel.")
            print("1. Go deeper\n2. Observe and report")
            if ask(2) == 1:
                ok = Combat.run(p, q["enemy"])
            else:
                ok = random.random() < (0.4 + p.stats.int * 0.02)

        self.cooldowns[q["name"]] = q["cd"]
        if ok:
            p.gain_xp(q["xp"])
            p.gold += q["gold"]
            p.rep += q["rep"]
            p.quests_done += 1
            print(f"Quest complete! +{q['xp']} XP +{q['gold']} Gold +{q['rep']} Rep")
            p.try_rank_up()
        else:
            loss = 2 if q["type"] in ["Escort", "Investigation"] else 1
            p.rep = max(0, p.rep - loss)
            print(f"Quest failed. Reputation -{loss}")

    def class_mentor(self):
        p = self._player()
        if p.level < 3 and not p.class_name:
            print("Class unlocks at level 3.")
            return
        if not p.class_name:
            print("1. Swordsman\n2. Mage\n3. Third Path (Locked)\n4. Back")
            c = ask(4)
            if c == 1:
                p.choose_class("Swordsman")
            elif c == 2:
                p.choose_class("Mage")
            elif c == 3:
                print("Third path is not available yet.")
                return
            else:
                return
            print(f"Class chosen: {p.class_name}")
            if p.skills:
                s = p.skills[0]
                print(f"First class skill: {s['name']} (MP {s['mp']}) ~{p.estimated_skill_damage(s)} dmg")
            return

        print(f"Mentor Hall ({p.class_name})")
        if p.class_name != "Mage":
            print(f"Crit Chance: {int(p.crit_chance() * 100)}%")
            print("Swordsman skills unlock naturally by level progression.")
            return
        if p.level >= 20 and not p.subclass_name:
            print("Choose Mage Branch:")
            print("1. Elementalist\n2. Necromancer\n3. Back")
            pick = ask(3)
            if pick == 1:
                p.choose_subclass("Elementalist")
                print("Advanced path chosen: Elementalist")
            elif pick == 2:
                p.choose_subclass("Necromancer")
                print("Advanced path chosen: Necromancer")
            return

        print("1. Train Novice Spell (50 Gold)")
        print("2. Learn Novice Spell (costs 20 sessions)")
        print("3. Train Advanced Spell (90 Gold, needs branch + Lv20)")
        print("4. Learn Advanced Spell (costs 8 sessions)")
        print("5. Back")
        c = ask(5)
        if c == 1:
            if p.class_name not in NOVICE_SKILLS:
                print("Your class trains techniques in battle, not novice spell lessons.")
                return
            if not p.train_novice():
                print("Need at least 50 Gold.")
                return
            print(f"Training complete. Sessions: {p.novice_training}/20")
        elif c == 2:
            if p.class_name not in NOVICE_SKILLS:
                print("No novice spell list for this class.")
                return
            if p.novice_training < 20:
                print(f"Need more training sessions: {p.novice_training}/20")
                return
            options = [s for s in NOVICE_SKILLS[p.class_name] if not any(k["name"] == s["name"] for k in p.skills)]
            if not options:
                print("All novice spells already learned.")
                return
            for i, s in enumerate(options, 1):
                print(f"{i}. {s['name']} ({s['element']}, MP {s['mp']}) ~{p.estimated_skill_damage(s)} dmg")
            pick = options[ask(len(options)) - 1]
            if p.learn_novice_spell(pick["name"]):
                print(f"Learned {pick['name']}!")
        elif c == 3:
            if not p.subclass_name:
                print("Choose a Mage branch at level 20 first.")
                return
            if p.level < 20:
                print("Need level 20+ for advanced lessons.")
                return
            if not p.train_proficient():
                options = [s for s in PROFICIENT_SKILLS.get(p.subclass_name or "", []) if not any(k["name"] == s["name"] for k in p.skills)]
                if not p.subclass_name:
                    print("Choose a Mage branch at level 20 first.")
                elif p.level < 20:
                    print("Need level 20+ for advanced lessons.")
                elif not options:
                    print("All advanced spells already learned.")
                elif p.proficient_training >= 8:
                    print("Advanced training is full at 8/8. Learn a spell to spend points.")
                else:
                    print("Need at least 90 Gold.")
                return
            print(f"Proficient training complete. Sessions: {p.proficient_training}/8")
        elif c == 4:
            if not p.subclass_name:
                print("No advanced branch selected.")
                return
            if p.proficient_training < 8:
                print(f"Need more proficient sessions: {p.proficient_training}/8")
                return
            options = [s for s in PROFICIENT_SKILLS[p.subclass_name] if not any(k["name"] == s["name"] for k in p.skills)]
            if not options:
                print("All proficient spells already learned.")
                return
            for i, s in enumerate(options, 1):
                print(f"{i}. {s['name']} ({s['element']}, MP {s['mp']}) ~{p.estimated_skill_damage(s)} dmg")
            pick = options[ask(len(options)) - 1]
            if p.learn_proficient_spell(pick["name"]):
                print(f"Learned {pick['name']}!")

    def shop(self):
        p = self._player()
        keys = list(ITEMS.keys())
        while True:
            print("\nShop:")
            for i, k in enumerate(keys, 1):
                print(f"{i}. {k} ({ITEMS[k]['price']}g)")
            print(f"{len(keys)+1}. Back")
            c = ask(len(keys) + 1)
            if c == len(keys) + 1:
                return
            item = keys[c - 1]
            if p.gold < ITEMS[item]["price"]:
                print("Not enough gold.")
                continue
            p.gold -= ITEMS[item]["price"]
            p.items[item] = p.items.get(item, 0) + 1
            print(f"Bought {item}.")

    def inventory_menu(self):
        p = self._player()
        while True:
            print("\nInventory:")
            if not p.items:
                print("(empty)")
            else:
                for k, v in p.items.items():
                    print(f"- {k} x{v}")
            eq_state = ", ".join([f"{slot}:{p.equip[slot] or 'none'}" for slot in ["weapon", "armor"]])
            print(f"Equipped -> {eq_state}")
            print("a) Equip  b) Use consumable  c) Unequip  d) Back")
            ch = input("> ").strip().lower()
            if ch == "d":
                return
            if ch == "b":
                con = [k for k, q in p.items.items() if q > 0 and ITEMS.get(k, {}).get("t") == "con"]
                if not con:
                    print("No consumables.")
                    continue
                for i, it in enumerate(con, 1):
                    print(f"{i}. {it}")
                it = con[ask(len(con)) - 1]
                p.items[it] -= 1
                if p.items[it] <= 0:
                    del p.items[it]
                d = ITEMS[it]
                if "heal" in d:
                    p.hp = min(p.stats.max_hp, p.hp + d["heal"])
                if "mp" in d:
                    p.mp = min(p.stats.max_mp, p.mp + d["mp"])
                print("Used.")
            elif ch == "a":
                eq = [k for k, q in p.items.items() if q > 0 and ITEMS.get(k, {}).get("t") == "eq"]
                if not eq:
                    print("No equipment.")
                    continue
                for i, it in enumerate(eq, 1):
                    print(f"{i}. {it} ({ITEMS[it]['slot']})")
                it = eq[ask(len(eq)) - 1]
                slot = ITEMS[it]["slot"]
                old = p.equip.get(slot)
                if old:
                    p.items[old] = p.items.get(old, 0) + 1
                p.items[it] -= 1
                if p.items[it] <= 0:
                    del p.items[it]
                p.equip[slot] = it
                p.refresh(full=False)
                print(f"Equipped {it}.")
            elif ch == "c":
                options = [slot for slot in ["weapon", "armor"] if p.equip.get(slot)]
                if not options:
                    print("Nothing equipped.")
                    continue
                for i, slot in enumerate(options, 1):
                    print(f"{i}. {slot}: {p.equip[slot]}")
                pick_slot = options[ask(len(options)) - 1]
                item = p.equip[pick_slot]
                if item is None:
                    print("Nothing to unequip.")
                    continue
                p.items[item] = p.items.get(item, 0) + 1
                p.equip[pick_slot] = None
                p.refresh(full=False)
                print(f"Unequipped {item}.")
            else:
                print("Invalid input.")

    def rest(self):
        cost = 10
        if self._player().gold < cost:
            print("You need 10 Gold to stay at the inn.")
            return
        self._player().gold -= cost
        p = self._player()
        self.day += 1
        for k in list(self.cooldowns.keys()):
            self.cooldowns[k] -= 1
            if self.cooldowns[k] <= 0:
                del self.cooldowns[k]
        p.refresh(full=True)
        print("You stay at the inn (meal included). HP/MP restored.")
        if random.random() < 0.35:
            ev = random.choice([
                ("A noble tips you.", lambda: setattr(p, "gold", p.gold + 20)),
                ("You found supplies.", lambda: p.items.__setitem__("Jerky", p.items.get("Jerky", 0) + 1)),
                ("Rumors hurt your image.", lambda: setattr(p, "rep", max(0, p.rep - 2))),
                ("You help townsfolk.", lambda: setattr(p, "rep", p.rep + 3)),
            ])
            print(f"Random Event: {ev[0]}")
            ev[1]()
        if p.karma <= 3 and random.random() < 0.22:
            print("\nA hooded assassin tracks your low-karma trail...")
            Combat.run(p, "Assassin")

    def show_char(self):
        p = self._player()
        print("\n=== Character ===")
        print(f"Name: {p.name}")
        print(f"Level: {p.level}  Rank: {p.rank}")
        print(f"XP: {p.exp}/{p.need_xp()}  Total XP: {p.total_xp()}")
        print(f"Gold: {p.gold}  Reputation: {p.rep}")
        print(f"Karma: {p.karma}/10")
        print(f"Class: {p.class_name or 'Unchosen'}")
        if p.subclass_name:
            print(f"Mage Branch: {p.subclass_name}")
        if p.class_name == "Swordsman":
            print(f"Crit Chance: {int(p.crit_chance() * 100)}%")
        if p.path_choice:
            print(f"A-Rank Path: {p.path_choice}")
        print(f"HP: {p.hp}/{p.stats.max_hp}  MP: {p.mp}/{p.stats.max_mp}")
        print(f"STR {p.stats.str}  INT {p.stats.int}  DEF {p.stats.defn}  AGI {p.stats.agi}")
        if p.skills:
            print("Skills:")
            for s in p.skills:
                print(f"- {s['name']} (MP {s['mp']})")
        else:
            print("Skills: None")
