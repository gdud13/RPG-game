import json
import os
import random
import html
import time
from typing import Dict, List, Optional

import streamlit as st

from game import CLASS_DATA, Combat, ENEMIES, ITEMS, KARMA_QUESTS, NOVICE_SKILLS, PROFICIENT_SKILLS, QUESTS, SPECIAL_LIEUTENANTS, Player, SPECIAL_REQUEST_NAME, rix

SAVE_FILE = "savegame.json"

NPCS = {
    "lyra": {
        "name": "Lyra Voss",
        "role": "Receptionist",
        "story": "She was once an adventurer scout, now keeper of guild records and old rumors.",
    },
    "selene": {
        "name": "Selene Arkwright",
        "role": "Mentor",
        "story": "An arcane veteran who survived the chapel war and now trains the next generation.",
    },
    "mirel": {
        "name": "Mirel Dane",
        "role": "Archivist",
        "story": "She curates forbidden reports and believes your missing past links to the chapel sigil.",
    },
    "elara": {
        "name": "Captain Elara Nyx",
        "role": "Field Captain",
        "story": "Commander of fast-response patrols. Stern, direct, and fiercely loyal to the city.",
    },
}


def inject_styles() -> None:
    st.markdown(
        """
<style>
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Source+Sans+3:wght@400;600&display=swap');

:root {
  --bg-a: #0a1220;
  --bg-b: #1f2f2b;
  --bg-c: #2f1f2f;
  --panel: rgba(13, 21, 37, 0.78);
  --panel-border: rgba(251, 191, 36, 0.42);
  --text: #f5f5e8;
  --muted: #d6d3c6;
  --accent: #fbbf24;
  --accent-strong: #f59e0b;
}

.stApp {
  background:
    radial-gradient(1200px 700px at 10% -10%, #1f3b73 0%, transparent 55%),
    radial-gradient(900px 650px at 100% 0%, #2d5b4f 0%, transparent 45%),
    radial-gradient(800px 500px at 50% 110%, #4c2950 0%, transparent 55%),
    linear-gradient(155deg, var(--bg-a), var(--bg-b) 55%, var(--bg-c));
  color: var(--text);
}

html, body, [data-testid="stAppViewContainer"], .stApp {
  height: 100vh;
  overflow: hidden;
}

[data-testid="stAppViewContainer"] .main {
  height: 100vh;
  overflow: hidden;
}

.block-container {
  height: 100vh;
  overflow: hidden;
  padding-bottom: 0.75rem;
}

h1, h2, h3 {
  font-family: "Cinzel", Georgia, serif !important;
  letter-spacing: 0.03em;
  color: var(--text);
}

p, span, label, li, .stMarkdown, .stCaption {
  font-family: "Source Sans 3", Segoe UI, sans-serif !important;
}

.rpg-panel {
  background: var(--panel);
  border: 1px solid var(--panel-border);
  border-radius: 16px;
  padding: 14px 16px;
  box-shadow: 0 16px 32px rgba(0, 0, 0, 0.35), inset 0 0 0 1px rgba(255,255,255,0.03);
  margin: 0 0 10px 0;
  backdrop-filter: blur(4px);
}

.rpg-grid-card {
  background: rgba(12, 18, 29, 0.76);
  border: 1px solid rgba(245, 158, 11, 0.28);
  border-radius: 12px;
  padding: 10px 12px;
  margin-bottom: 8px;
}

.rpg-quest-card {
  background: linear-gradient(165deg, rgba(15,23,42,0.85), rgba(30,41,59,0.65));
  border: 1px solid rgba(251, 191, 36, 0.30);
  border-radius: 12px;
  padding: 9px 11px;
  margin-bottom: 8px;
  min-height: 150px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.mission-meta {
  color: #e8dec2;
  font-size: 0.92rem;
  line-height: 1.35;
}

.dialogue-stage {
  background: linear-gradient(175deg, rgba(13,21,37,0.95), rgba(27,39,58,0.88));
  border: 1px solid rgba(251, 191, 36, 0.36);
  border-radius: 16px;
  padding: 18px 20px;
  min-height: 280px;
  box-shadow: 0 18px 34px rgba(0, 0, 0, 0.35);
}

.dialogue-stage h3 {
  margin: 0 0 6px 0;
}

.dialogue-stage .sub {
  color: #e6dcc4;
  font-size: 0.95rem;
  margin-bottom: 10px;
}

.event-log-stage {
  background: linear-gradient(180deg, rgba(8,14,26,0.97), rgba(24,36,54,0.92));
  border: 1px solid rgba(251, 191, 36, 0.45);
  border-radius: 16px;
  padding: 14px 16px;
  min-height: 170px;
  max-height: 31vh;
  overflow-y: auto;
  margin-bottom: 10px;
  box-shadow: 0 18px 32px rgba(0, 0, 0, 0.4);
}

.event-log-current {
  font-size: 1.08rem;
  line-height: 1.45;
  color: #fff3ca;
  margin-bottom: 10px;
  border-left: 3px solid rgba(251, 191, 36, 0.65);
  padding-left: 10px;
}

.journal-stage {
  background: linear-gradient(176deg, rgba(9,16,29,0.96), rgba(29,42,62,0.92));
  border: 1px solid rgba(251, 191, 36, 0.38);
  border-radius: 16px;
  padding: 16px 18px;
  min-height: 260px;
  max-height: 58vh;
  overflow-y: auto;
  box-shadow: 0 16px 30px rgba(0, 0, 0, 0.36);
}

.log-line {
  font-size: 1.02rem;
  line-height: 1.45;
  color: #f0ead4;
  margin-bottom: 8px;
}

.rpg-kv {
  color: #efe8d0;
  font-size: 0.95rem;
}

.rpg-kv strong {
  color: #ffdfa3;
}

.rpg-title {
  font-family: "Cinzel", Georgia, serif;
  font-size: 2.2rem;
  font-weight: 700;
  color: #fff6d8;
  margin-bottom: 6px;
}

.rpg-badge {
  display: inline-block;
  padding: 4px 9px;
  border: 1px solid rgba(251, 191, 36, 0.5);
  border-radius: 999px;
  font-size: 0.82rem;
  color: #ffe7b0;
  margin-right: 6px;
  margin-bottom: 4px;
  background: rgba(0,0,0,0.22);
}

.rpg-sub {
  color: var(--muted);
  font-size: 1rem;
}

.rpg-hud {
  font-family: "Source Sans 3", Segoe UI, sans-serif;
  color: var(--text);
}

.stButton > button {
  border-radius: 12px;
  border: 1px solid rgba(245, 158, 11, 0.5);
  background: linear-gradient(180deg, #253247, #182234);
  color: #f9f7ef;
  font-weight: 600;
  transition: all 120ms ease-in-out;
}

.stButton > button:hover {
  border-color: var(--accent);
  background: linear-gradient(180deg, #3a4b66, #26344a);
  box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.15);
  transform: translateY(-1px);
}

.stButton > button:focus:not(:active) {
  border-color: var(--accent-strong);
}

[data-testid="stSidebar"] {
  background: rgba(0, 0, 0, 0.2);
}
</style>
        """,
        unsafe_allow_html=True,
    )


def set_scroll_mode(enable_scroll: bool) -> None:
    if enable_scroll:
        st.markdown(
            """
<style>
[data-testid="stAppViewContainer"], .stApp {
  overflow-y: auto !important;
}
[data-testid="stAppViewContainer"] .main {
  overflow-y: auto !important;
}
.block-container {
  height: auto !important;
  overflow-y: visible !important;
}
</style>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            """
<style>
[data-testid="stAppViewContainer"], .stApp {
  overflow: hidden !important;
}
[data-testid="stAppViewContainer"] .main {
  overflow: hidden !important;
}
.block-container {
  height: 100vh !important;
  overflow: hidden !important;
}
</style>
            """,
            unsafe_allow_html=True,
        )


def init_state() -> None:
    if "player" not in st.session_state:
        st.session_state.player = None
    if "day" not in st.session_state:
        st.session_state.day = 1
    if "cooldowns" not in st.session_state:
        st.session_state.cooldowns = {}
    if "screen" not in st.session_state:
        st.session_state.screen = "start"
    if "combat" not in st.session_state:
        st.session_state.combat = None
    if "selected_quest" not in st.session_state:
        st.session_state.selected_quest = None
    if "log" not in st.session_state:
        st.session_state.log = []
    if "story_flags" not in st.session_state:
        st.session_state.story_flags = {}
    if "story_journal" not in st.session_state:
        st.session_state.story_journal = []
    if "special_state" not in st.session_state:
        st.session_state.special_state = "locked"
    if "special_round" not in st.session_state:
        st.session_state.special_round = 0
    if "npc_selected" not in st.session_state:
        st.session_state.npc_selected = "lyra"
    if "npc_bond" not in st.session_state:
        st.session_state.npc_bond = {k: 0 for k in NPCS.keys()}
    if "npc_flags" not in st.session_state:
        st.session_state.npc_flags = {}
    if "intro_lines" not in st.session_state:
        st.session_state.intro_lines = []
    if "intro_index" not in st.session_state:
        st.session_state.intro_index = 0
    if "intro_ready_at" not in st.session_state:
        st.session_state.intro_ready_at = 0.0
    if "intro_phase" not in st.session_state:
        st.session_state.intro_phase = "prologue"
    if "intro_name_input" not in st.session_state:
        st.session_state.intro_name_input = ""
    if "promo_notice" not in st.session_state:
        st.session_state.promo_notice = ""


def push(msg: str) -> None:
    st.session_state.log.append(msg)
    st.session_state.log = st.session_state.log[-12:]


def journal_note(msg: str, key: str = "") -> None:
    if key and st.session_state.story_flags.get(key):
        return
    if key:
        st.session_state.story_flags[key] = True
    st.session_state.story_journal.append(msg)
    st.session_state.story_journal = st.session_state.story_journal[-20:]


def chronicle(msg: str, key: str = "") -> None:
    journal_note(msg, key)
    push(msg)


def item_tooltip(name: str) -> str:
    d = ITEMS[name]
    parts = []
    if d.get("t") == "con":
        if "heal" in d:
            parts.append(f"Heal +{d['heal']} HP")
        if "mp" in d:
            parts.append(f"Restore +{d['mp']} MP")
    if d.get("t") == "eq":
        parts.append(f"Slot: {d['slot']}")
        mods = d.get("mods", {})
        if mods:
            parts.append("Stats: " + ", ".join([f"{k.upper()} +{v}" for k, v in mods.items()]))
    parts.append(f"Price: {d['price']}g")
    return " | ".join(parts)


def receptionist_greeting(p: Player) -> str:
    if rix(p.rank) >= rix("B"):
        return f'Welcome sir {p.name}.'
    return f"Welcome {p.name}."


def maybe_story_progress() -> None:
    p = st.session_state.player
    if p is None:
        return
    if p.level >= 3:
        chronicle("Mentor Selene nods: 'Your aura is stabilizing. You're ready for a class path.'", "story_lvl3")
    if p.rank in ["E", "D", "C", "B", "A", "S"]:
        chronicle("Guildmaster Orin studies your record and moves your file to a red-sealed cabinet.", "story_rank_e")
    if p.rank in ["C", "B", "A", "S"]:
        chronicle("Quartermaster Bram mutters that caravans now ask for you by name.", "story_rank_c")
    if p.level >= 5 and st.session_state.special_state == "locked":
        st.session_state.special_state = "offered"
        chronicle("Guildmaster Orin files a special mission to your board: Black-Banner Camp.", "story_special_offer")
    if p.rank in ["B", "A", "S"]:
        chronicle("Archivist Mirel reveals a page about your missing memories and the chapel sigil.", "story_rank_b")


def save_game() -> None:
    p = st.session_state.player
    data = {
        "player": p.to_dict(),
        "day": st.session_state.day,
        "cooldowns": st.session_state.cooldowns,
        "special_state": st.session_state.special_state,
        "special_round": st.session_state.special_round,
        "story_flags": st.session_state.story_flags,
        "story_journal": st.session_state.story_journal,
        "npc_selected": st.session_state.npc_selected,
        "npc_bond": st.session_state.npc_bond,
        "npc_flags": st.session_state.npc_flags,
    }
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    push("Game saved.")


def load_game() -> bool:
    if not os.path.exists(SAVE_FILE):
        push("No save file found.")
        return False
    with open(SAVE_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    st.session_state.player = Player.from_dict(data["player"])
    st.session_state.day = data.get("day", 1)
    st.session_state.cooldowns = data.get("cooldowns", {})
    st.session_state.special_state = data.get("special_state", "locked")
    st.session_state.special_round = data.get("special_round", 0)
    st.session_state.story_flags = data.get("story_flags", {})
    st.session_state.story_journal = data.get("story_journal", [])
    st.session_state.npc_selected = data.get("npc_selected", "lyra")
    st.session_state.npc_bond = data.get("npc_bond", {k: 0 for k in NPCS.keys()})
    st.session_state.npc_flags = data.get("npc_flags", {})
    st.session_state.screen = "main"
    st.session_state.combat = None
    push(f"Loaded {st.session_state.player.name} (Day {st.session_state.day}).")
    maybe_story_progress()
    return True


def available_quests(p: Player, cooldowns: Dict[str, int]) -> List[Dict]:
    out: List[Dict] = []
    for q in QUESTS:
        if rix(p.rank) < rix(q["min"]):
            continue
        if q["name"] in cooldowns:
            continue
        if p.class_name == "Mage" and p.subclass_name == "Necromancer" and q["type"] == "Escort":
            continue
        out.append(q)
    for q in KARMA_QUESTS:
        if rix(p.rank) < rix(q["min"]):
            continue
        if q["name"] in cooldowns:
            continue
        if p.karma < q["karma_min"] or p.karma > q["karma_max"]:
            continue
        out.append(q)
    if p.level >= 5 and st.session_state.special_state in ["offered", "active", "twist"]:
        out.append({
            "name": SPECIAL_REQUEST_NAME,
            "type": "Special",
            "min": "Any",
            "gold": 0,
            "xp": 0,
            "rep": 0,
            "cd": 0,
        })
    return out


def start_combat(enemy_name: str, enemy_override: Optional[Dict] = None, source: str = "mission") -> None:
    e = (enemy_override or ENEMIES[enemy_name]).copy()
    if not e.get("_scaled"):
        e["hp"] = max(1, int(e["hp"] * 1.2))
        e["def"] = max(1, int(e["def"] * 1.1))
        e["_scaled"] = True
    st.session_state.combat = {
        "enemy_name": enemy_name,
        "enemy": e,
        "ehp": e["hp"],
        "emp": e["mp"],
        "status": "ongoing",
        "source": source,
        "bleed_turns": 0,
        "bleed_dmg": 0,
        "poison_turns": 0,
        "poison_dmg": 0,
        "stun_turns": 0,
        "skeleton_guard_hp": 0,
    }
    st.session_state.screen = "combat"
    push(f"Combat started against {enemy_name}.")


def enemy_turn() -> None:
    c = st.session_state.combat
    p = st.session_state.player
    e = c["enemy"]
    if c["ehp"] <= 0 or p.hp <= 0:
        return
    if c.get("stun_turns", 0) > 0:
        c["stun_turns"] -= 1
        push(f"{c['enemy_name']} is stunned and misses a turn.")
        return
    if c["emp"] >= 8 and e["int"] > e["str"] and random.random() < 0.45:
        c["emp"] -= 8
        d = Combat.dmg(e["int"] + 3, p.stats.defn + p.guard, 1.2)
        d = int(d * 1.3)
        d = int(d * e.get("dmg_mult", 1.0))
        push(f"{c['enemy_name']} casts for {d}.")
    else:
        d = Combat.dmg(e["str"], p.stats.defn + p.guard, 1.0)
        d = int(d * 1.3)
        d = int(d * e.get("dmg_mult", 1.0))
        push(f"{c['enemy_name']} attacks for {d}.")
    if random.random() < 0.12:
        d = int(d * 1.35)
        push(f"{c['enemy_name']} lands a critical hit!")
    if c.get("skeleton_guard_hp", 0) > 0 and not e.get("aoe", False):
        c["skeleton_guard_hp"] = max(0, c["skeleton_guard_hp"] - d)
        push(f"Skeleton guard blocks {d} damage.")
        if c["skeleton_guard_hp"] <= 0:
            push("Skeleton guard crumbles.")
    else:
        p.hp = max(0, p.hp - d)
    p.guard = 0


def apply_enemy_dot() -> None:
    c = st.session_state.combat
    e = c["enemy"]
    if c.get("bleed_turns", 0) > 0 and e.get("flesh", False):
        c["ehp"] = max(0, c["ehp"] - c.get("bleed_dmg", 0))
        c["bleed_turns"] -= 1
        push(f"{c['enemy_name']} bleeds for {c.get('bleed_dmg', 0)}.")
    if c.get("poison_turns", 0) > 0:
        c["ehp"] = max(0, c["ehp"] - c.get("poison_dmg", 0))
        c["poison_turns"] -= 1
        push(f"{c['enemy_name']} suffers poison for {c.get('poison_dmg', 0)}.")


def finish_combat_if_done() -> bool:
    c = st.session_state.combat
    p = st.session_state.player
    if c["ehp"] > 0 and p.hp > 0:
        return False

    if p.hp > 0:
        xp = c["enemy"]["xp"]
        gold = c["enemy"]["gold"]
        p.gain_xp(xp)
        p.gold += gold
        push(f"Victory! +{xp} XP, +{gold} Gold.")
        c["status"] = "won"
    else:
        p.gold = max(0, p.gold - 25)
        p.hp = max(1, p.stats.max_hp // 2)
        p.mp = max(0, p.stats.max_mp // 2)
        push("Defeat. Guild medics rescue you. -25 Gold.")
        c["status"] = "lost"
    return True


def combat_action_attack() -> None:
    c = st.session_state.combat
    p = st.session_state.player
    apply_enemy_dot()
    if finish_combat_if_done():
        return
    d = Combat.dmg(p.stats.str, c["enemy"]["def"], 1.0)
    if p.class_name == "Swordsman" and random.random() < p.crit_chance():
        d *= 2
        push("Critical hit!")
    c["ehp"] = max(0, c["ehp"] - d)
    push(f"You hit for {d}.")
    if finish_combat_if_done():
        return
    enemy_turn()
    finish_combat_if_done()


def combat_action_defend() -> None:
    p = st.session_state.player
    apply_enemy_dot()
    if finish_combat_if_done():
        return
    p.guard = 6
    push("You defend.")
    enemy_turn()
    finish_combat_if_done()


def combat_action_flee() -> None:
    c = st.session_state.combat
    p = st.session_state.player
    apply_enemy_dot()
    if finish_combat_if_done():
        return
    e = c["enemy"]
    chance = max(0.05, min(0.9, 0.28 + (p.stats.agi - e["agi"]) * 0.03))
    if random.random() < chance:
        c["status"] = "fled"
        push("Escaped.")
        return
    push("Could not flee.")
    enemy_turn()
    finish_combat_if_done()


def use_consumable(item_name: str) -> None:
    p = st.session_state.player
    if p.items.get(item_name, 0) <= 0:
        return
    p.items[item_name] -= 1
    if p.items[item_name] <= 0:
        del p.items[item_name]
    data = ITEMS[item_name]
    if "heal" in data:
        p.hp = min(p.stats.max_hp, p.hp + data["heal"])
        push(f"+{data['heal']} HP")
    if "mp" in data:
        p.mp = min(p.stats.max_mp, p.mp + data["mp"])
        push(f"+{data['mp']} MP")


def equip_item(item_name: str) -> None:
    p = st.session_state.player
    if p.items.get(item_name, 0) <= 0:
        return
    slot = ITEMS[item_name]["slot"]
    old = p.equip.get(slot)
    if old:
        p.items[old] = p.items.get(old, 0) + 1
    p.items[item_name] -= 1
    if p.items[item_name] <= 0:
        del p.items[item_name]
    p.equip[slot] = item_name
    p.refresh(full=False)
    push(f"Equipped {item_name}.")


def unequip_item(slot: str) -> None:
    p = st.session_state.player
    it = p.equip.get(slot)
    if not it:
        return
    p.items[it] = p.items.get(it, 0) + 1
    p.equip[slot] = None
    p.refresh(full=False)
    push(f"Unequipped {it}.")


def apply_quest_outcome(q: Dict, ok: bool) -> None:
    p = st.session_state.player
    st.session_state.cooldowns[q["name"]] = q["cd"]
    if ok:
        p.gain_xp(q["xp"])
        p.gold += q["gold"]
        p.rep += q["rep"]
        p.quests_done += 1
        gained = p.try_rank_up()
        if gained > 0:
            push(f"Promotion check passed: +{gained} rank.")
        push(f"Quest complete! +{q['xp']} XP, +{q['gold']} Gold, +{q['rep']} Rep.")
        maybe_story_progress()
    else:
        loss = 2 if q["type"] in ["Escort", "Investigation"] else 1
        p.rep = max(0, p.rep - loss)
        push(f"Quest failed. Reputation -{loss}.")


def run_noncombat_quest(q: Dict, choice: str = "default") -> None:
    p = st.session_state.player
    if q["type"] == "Gathering":
        chance = max(0.2, min(0.9, 0.55 + (p.stats.int + p.stats.agi - 14) * 0.015))
        ok = random.random() < chance
        if ok and random.random() < 0.3:
            p.items["Potion"] = p.items.get("Potion", 0) + 1
            push("Found Potion.")
        apply_quest_outcome(q, ok)
        return

    if q["type"] == "Investigation" and choice == "observe":
        ok = random.random() < (0.4 + p.stats.int * 0.02)
        apply_quest_outcome(q, ok)


def do_rest() -> None:
    p = st.session_state.player
    cost = 10
    if p.gold < cost:
        push("You need 10 Gold for an inn stay.")
        return
    p.gold -= cost
    st.session_state.day += 1
    for k in list(st.session_state.cooldowns.keys()):
        st.session_state.cooldowns[k] -= 1
        if st.session_state.cooldowns[k] <= 0:
            del st.session_state.cooldowns[k]
    p.refresh(full=True)
    push("You stay at the inn (10 Gold, meal included). HP/MP restored.")
    if random.random() < 0.35:
        ev = random.choice([
            ("A noble tips you.", lambda: setattr(p, "gold", p.gold + 20)),
            ("You found supplies.", lambda: p.items.__setitem__("Jerky", p.items.get("Jerky", 0) + 1)),
            ("Rumors hurt your image.", lambda: setattr(p, "rep", max(0, p.rep - 2))),
            ("You help townsfolk.", lambda: setattr(p, "rep", p.rep + 3)),
        ])
        push(f"Random Event: {ev[0]}")
        ev[1]()
    if st.session_state.day in [3, 7, 14]:
        story = {
            3: "Receptionist Lyra quietly says your name appeared in a ledger before your arrival.",
            7: "At dinner, Captain Rook warns that the Ruined Chapel reacts to marked adventurers.",
            14: "Guildmaster Orin orders a private briefing: 'This is no ordinary rank climb.'",
        }[st.session_state.day]
        chronicle(story, f"story_day_{st.session_state.day}")
    if p.karma <= 3 and random.random() < 0.22:
        chronicle("A hired assassin finds your trail in the night.", "story_assassin_hint")
        start_combat("Assassin", source="assassin")


def npc_interaction(npc_id: str, action: str) -> None:
    p = st.session_state.player
    if npc_id not in NPCS:
        return
    st.session_state.npc_bond[npc_id] = min(10, st.session_state.npc_bond.get(npc_id, 0) + 1)
    if npc_id == "lyra":
        if action == "chat":
            push("Lyra: 'Your name appears in records older than your arrival date.'")
            journal_note("Clue: Your name appears in guild records older than your arrival.", "lyra_chat")
        elif action == "favor":
            key = f"lyra_favor_day_{st.session_state.day}"
            if st.session_state.npc_flags.get(key):
                push("Lyra already sorted your paperwork today.")
                return
            st.session_state.npc_flags[key] = True
            p.rep += 1
            push("Lyra files your reports cleanly. Reputation +1.")
    elif npc_id == "selene":
        if action == "chat":
            push("Selene: 'Power without restraint is how chapel ghosts are born.'")
            journal_note("Mentor Note: Control matters as much as power.", "selene_chat")
        elif action == "favor":
            key = f"selene_drill_day_{st.session_state.day}"
            if st.session_state.npc_flags.get(key):
                push("Selene has already drilled you today.")
                return
            st.session_state.npc_flags[key] = True
            p.gain_xp(35)
            p.mp = min(p.stats.max_mp, p.mp + 12)
            push("Selene runs a focus drill. +35 XP and +12 MP.")
    elif npc_id == "mirel":
        if action == "chat":
            push("Mirel: 'This torn ledger links bandits, sigils, and missing guild seals.'")
            journal_note("Clue: Bandits, sigils, and missing guild seals may be connected.", "mirel_chat")
        elif action == "favor":
            if p.gold < 20:
                push("Need 20 Gold for archive access.")
                return
            p.gold -= 20
            p.items["Mana Potion"] = p.items.get("Mana Potion", 0) + 1
            push("Mirel sells you sealed notes and a Mana Potion.")
    elif npc_id == "elara":
        if action == "chat":
            push("Elara: 'Compassion is useful. Hesitation is fatal. Learn the difference.'")
        elif action == "favor":
            push("Elara sets up a live drill against a rogue harpy scout.")
            start_combat("Harpy", source="npc")


def render_npc_hall() -> None:
    render_top_bar()
    st.markdown(
        '<div class="rpg-panel"><div class="rpg-title" style="font-size:1.25rem;">Guild Commons</div>'
        '<span class="rpg-kv">Meet key guild women, build trust, and unlock side stories.</span></div>',
        unsafe_allow_html=True,
    )
    left, center, right = st.columns([1.2, 2.8, 1.2])
    with left:
        st.write("People")
        for nid, data in NPCS.items():
            bond = st.session_state.npc_bond.get(nid, 0)
            if st.button(f"{data['name']} ({data['role']})", key=f"npc-{nid}", use_container_width=True):
                st.session_state.npc_selected = nid
                st.rerun()
            st.caption(f"Bond {bond}/10")
    with center:
        nid = st.session_state.npc_selected
        data = NPCS[nid]
        st.markdown(
            f'<div class="dialogue-stage"><h3>{data["name"]}</h3>'
            f'<div class="sub">{data["role"]}</div>'
            f'<div class="rpg-kv">{data["story"]}</div></div>',
            unsafe_allow_html=True,
        )
        c1, c2 = st.columns(2)
        if c1.button("Talk", key=f"talk-{nid}", use_container_width=True):
            npc_interaction(nid, "chat")
            st.rerun()
        action_label = "Request Help"
        if nid == "elara":
            action_label = "Sparring Drill"
        if c2.button(action_label, key=f"favor-{nid}", use_container_width=True):
            npc_interaction(nid, "favor")
            st.rerun()
    with right:
        st.write("Notes")
        st.caption("Higher bond will be used for later quest branches.")
        if st.button("Back To Main", use_container_width=True):
            st.session_state.screen = "main"
            st.rerun()


def render_start() -> None:
    st.markdown(
        """
<div class="rpg-panel">
  <div class="rpg-title">Reincarnated Guild Chronicle</div>
  <div class="rpg-sub">A browser journey through rank, steel, and rumor.</div>
</div>
        """,
        unsafe_allow_html=True,
    )
    c1, c2 = st.columns(2)
    with c1:
        if st.button("New Game", use_container_width=True):
            st.session_state.player = Player("Nameless")
            st.session_state.day = 1
            st.session_state.cooldowns = {}
            st.session_state.log = []
            st.session_state.story_flags = {}
            st.session_state.story_journal = []
            st.session_state.special_state = "locked"
            st.session_state.special_round = 0
            st.session_state.npc_selected = "lyra"
            st.session_state.npc_bond = {k: 0 for k in NPCS.keys()}
            st.session_state.npc_flags = {}
            st.session_state.intro_lines = [
                "A patrol finds you unconscious in a wheat field beyond the eastern road.",
                "No papers. No guild tag. No memory worth trusting.",
                "The guards bring you to the inn and keep watch through the night.",
                "At dawn, the guild is notified.",
            ]
            st.session_state.intro_index = 0
            st.session_state.intro_ready_at = time.time()
            st.session_state.intro_phase = "prologue"
            st.session_state.intro_name_input = ""
            push(st.session_state.intro_lines[0])
            st.session_state.screen = "intro"
            st.rerun()
    with c2:
        if st.button("Load Game", use_container_width=True):
            load_game()
            st.rerun()


def render_top_bar() -> None:
    p = st.session_state.player
    st.markdown(
        f"""
<div class="rpg-panel rpg-hud">
  <strong>Day {st.session_state.day}</strong> | {p.name} Lv{p.level} {p.rank}-Rank<br>
  HP {p.hp}/{p.stats.max_hp} | MP {p.mp}/{p.stats.max_mp} | Gold {p.gold} | Rep {p.rep} | Karma {p.karma}/10 | Class: {p.class_name or "Unchosen"} | Quests: {p.quests_done}
</div>
        """,
        unsafe_allow_html=True,
    )
    bar_left, bar_mid, bar_right = st.columns([2, 2, 3])
    with bar_left:
        st.progress(p.hp / max(1, p.stats.max_hp), text=f"HP {p.hp}/{p.stats.max_hp}")
    with bar_mid:
        st.progress(p.mp / max(1, p.stats.max_mp), text=f"MP {p.mp}/{p.stats.max_mp}")
    with bar_right:
        nxt = p.requirements_for_next_rank()
        if nxt:
            st.caption(
                f"Next {nxt['target']}: XP {nxt['xp'][0]}/{nxt['xp'][1]} | "
                f"Quests {nxt['quests'][0]}/{nxt['quests'][1]} | Rep {nxt['rep'][0]}/{nxt['rep'][1]}"
            )
        else:
            st.caption("Max rank reached.")
    render_event_log()


def render_event_log() -> None:
    if not st.session_state.log:
        st.markdown(
            '<div class="event-log-stage"><div class="rpg-title" style="font-size:1.2rem;">Event Log</div><div class="rpg-kv">No events yet.</div></div>',
            unsafe_allow_html=True,
        )
        return

    current = st.session_state.log[-1]
    st.markdown(
        (
            '<div class="event-log-stage">'
            '<div class="rpg-title" style="font-size:1.2rem;">Event Log</div>'
            f'<div class="event-log-current">{html.escape(current)}</div>'
            '</div>'
        ),
        unsafe_allow_html=True,
    )


def render_intro() -> None:
    p = st.session_state.player
    render_top_bar()
    phase = st.session_state.intro_phase
    can_advance = time.time() >= st.session_state.intro_ready_at

    if phase == "prologue":
        if st.button("Next", use_container_width=True):
            if not can_advance:
                return
            if st.session_state.intro_index < len(st.session_state.intro_lines) - 1:
                st.session_state.intro_index += 1
                push(st.session_state.intro_lines[st.session_state.intro_index])
                st.session_state.intro_ready_at = time.time() + 1.0
            else:
                push(
                    "Receptionist Lyra: 'Welcome, are you feeling better? The guards found you passed out, do you remember your name?'"
                )
                st.session_state.intro_phase = "name_memory"
                st.session_state.intro_ready_at = time.time() + 1.0
            st.rerun()
        return

    if phase == "name_memory":
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Yes, I remember", use_container_width=True):
                push("Lyra: 'Good. Tell me your name so I can register you.'")
                st.session_state.intro_phase = "enter_name"
                st.rerun()
        with c2:
            if st.button("No, I don't", use_container_width=True):
                push("Lyra: 'That's alright. Tell me the name you want us to call you.'")
                st.session_state.intro_phase = "enter_name"
                st.rerun()
        return

    if phase == "enter_name":
        if p is None:
            st.session_state.screen = "start"
            st.rerun()
        st.session_state.intro_name_input = st.text_input(
            "Your name",
            value=st.session_state.intro_name_input,
            max_chars=24,
        )
        if st.button("Confirm Name", use_container_width=True):
            nm = (st.session_state.intro_name_input or "").strip()
            if not nm:
                st.warning("You must enter a name before continuing.")
                return
            p.name = nm
            push(
                f"Lyra: '{nm}? well at least you're awake and well, so I am sure you're ready for work. Should I explain to you how the guild works?'"
            )
            st.session_state.intro_phase = "guild_explain_choice"
            st.rerun()
        return

    if phase == "guild_explain_choice":
        c1, c2 = st.columns(2)
        with c1:
            st.caption("Yes: Learn how missions, ranks, and mentors work.")
            if st.button("Yes, explain", use_container_width=True):
                push(
                    "Lyra: 'You can take on small tasks and missions and slowly work your way up the ranks. Then, you can specialize your skills with the guild mentors.'"
                )
                journal_note("Guild Basics: Take missions, rank up, then specialize with mentors.", "journal_guild_basics")
                journal_note("Objective: Visit the Guild Hall and accept your first mission.", "journal_first_objective")
                st.session_state.intro_phase = "intro_done"
                st.rerun()
        with c2:
            st.caption("No: For experienced players.")
            if st.button("No (For experienced players)", use_container_width=True):
                push("Lyra: 'Understood. (For experienced players.)'")
                journal_note("Objective: Visit the Guild Hall and accept your first mission.", "journal_first_objective")
                st.session_state.intro_phase = "intro_done"
                st.rerun()
        return

    if phase == "intro_done":
        if st.button("Begin Guild Life", use_container_width=True):
            push(f"Lyra: '{receptionist_greeting(p)}'")
            st.session_state.screen = "main"
            st.rerun()


def render_main() -> None:
    render_top_bar()
    p = st.session_state.player
    st.markdown(
        f'<div class="rpg-grid-card"><span class="rpg-kv"><strong>Lyra:</strong> {html.escape(receptionist_greeting(p))}</span></div>',
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button("Guild Hall", use_container_width=True):
            st.session_state.screen = "guild"
            st.rerun()
        if st.button("Inventory", use_container_width=True):
            st.session_state.screen = "inventory"
            st.rerun()
    with c2:
        if st.button("Character", use_container_width=True):
            st.session_state.screen = "character"
            st.rerun()
        if st.button("Inn Stay (10g)", use_container_width=True):
            do_rest()
            st.rerun()
        if st.button("Guild Commons", use_container_width=True):
            st.session_state.screen = "npcs"
            st.rerun()
    with c3:
        if st.button("Journal", use_container_width=True):
            st.session_state.screen = "journal"
            st.rerun()
        if st.button("Save", use_container_width=True):
            save_game()
            st.rerun()
        if st.button("Back To Start", use_container_width=True):
            st.session_state.screen = "start"
            st.rerun()


def render_journal() -> None:
    render_top_bar()
    lines = st.session_state.story_journal
    entries = "".join(f'<div class="log-line">{html.escape(m)}</div>' for m in lines) if lines else '<div class="rpg-kv">No journal notes yet.</div>'
    st.markdown(
        (
            '<div class="journal-stage">'
            '<div class="rpg-title" style="font-size:1.35rem;">Journal</div>'
            '<div class="rpg-kv"><strong>Important Notes & Objectives</strong></div>'
            f'{entries}'
            '</div>'
        ),
        unsafe_allow_html=True,
    )
    if st.button("Back", use_container_width=True):
        st.session_state.screen = "main"
        st.rerun()


def render_guild() -> None:
    p = st.session_state.player
    maybe_story_progress()
    render_top_bar()
    st.write("Guild Hall")
    if st.session_state.promo_notice:
        st.info(st.session_state.promo_notice)
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button("Accept Mission", use_container_width=True):
            st.session_state.promo_notice = ""
            st.session_state.screen = "missions"
            st.rerun()
        if st.button("Promotion Check", use_container_width=True):
            gained = p.try_rank_up()
            if gained == 0:
                nxt = p.requirements_for_next_rank()
                if nxt:
                    st.session_state.promo_notice = (
                        f"Not eligible yet. Need XP {nxt['xp'][0]}/{nxt['xp'][1]}, "
                        f"Quests {nxt['quests'][0]}/{nxt['quests'][1]}, Rep {nxt['rep'][0]}/{nxt['rep'][1]}."
                    )
                    push(
                        f"Not eligible yet. Need XP {nxt['xp'][0]}/{nxt['xp'][1]}, "
                        f"Quests {nxt['quests'][0]}/{nxt['quests'][1]}, Rep {nxt['rep'][0]}/{nxt['rep'][1]}."
                    )
                else:
                    st.session_state.promo_notice = "You are already S-Rank."
                    push("You are already S-Rank.")
            else:
                st.session_state.promo_notice = f"Promotion successful. Rank increased by {gained}."
                push(f"Promotion successful. Rank increased by {gained}.")
                maybe_story_progress()
            if p.rank == "A" and not p.path_choice:
                p.path_choice = "Elite Adventurer"
                push("Path chosen: Elite Adventurer.")
            st.rerun()
    with c2:
        if st.button("Shop", use_container_width=True):
            st.session_state.promo_notice = ""
            st.session_state.screen = "shop"
            st.rerun()
        if st.button("Class Mentor", use_container_width=True):
            st.session_state.promo_notice = ""
            st.session_state.screen = "class"
            st.rerun()
    with c3:
        if st.button("Back", use_container_width=True):
            st.session_state.promo_notice = ""
            st.session_state.screen = "main"
            st.rerun()


def render_special_request() -> None:
    render_top_bar()
    st.markdown(
        '<div class="rpg-panel"><div class="rpg-title" style="font-size:1.2rem;">Black-Banner Camp</div>'
        '<span class="rpg-kv">Survive five lieutenant duels. Each one is stronger than standard field bandits.</span></div>',
        unsafe_allow_html=True,
    )
    state = st.session_state.special_state
    if state == "locked":
        st.info("The sealed request is not active yet.")
    elif state == "done":
        st.success("This quest chain has been resolved.")
    elif state == "offered":
        st.info("Guildmaster Orin posted this mission on your board.")
        if st.button("Accept Black-Banner Camp Quest", use_container_width=True):
            st.session_state.special_state = "active"
            st.session_state.special_round = 1
            chronicle("You accept Orin's order to clear Black-Banner Camp.", "story_special_accept")
            st.rerun()
    elif state == "twist":
        st.info("The camp is clear. The bandit chief asks for mercy in exchange for all stolen coin.")
        if st.button("Enter Command Tent", use_container_width=True):
            st.session_state.screen = "special_twist"
            st.rerun()
    else:
        rd = st.session_state.special_round
        lt = SPECIAL_LIEUTENANTS[rd - 1]
        st.write(f"LIEUTENANT ROUND {rd}/5")
        st.caption(
            f"{lt['name']} | HP {lt['hp']} | STR {lt['str']} | DEF {lt['def']} | AGI {lt['agi']} | "
            f"Weak: {', '.join(lt.get('weak', []))}"
        )
        if st.button("Engage Next Lieutenant", use_container_width=True):
            foe = dict(lt)
            foe_name = foe.pop("name")
            start_combat(foe_name, foe, "special_wave")
            st.rerun()
    if st.button("Back To Guild"):
        st.session_state.screen = "guild"
        st.rerun()


def render_special_twist() -> None:
    p = st.session_state.player
    render_top_bar()
    st.markdown(
        '<div class="rpg-panel"><div class="rpg-title" style="font-size:1.15rem;">Bandit Chief\'s Plea</div>'
        '<span class="rpg-kv">Their leader offers full restitution if you spare them and force exile. '
        'Guild law also permits immediate execution and return of stolen wealth.</span></div>',
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    if c1.button("Mercy: Take coin, shoo away", use_container_width=True):
        p.add_karma(1)
        p.gold += 320
        p.gain_xp(320)
        p.quests_done += 1
        st.session_state.special_state = "done"
        chronicle("You spare the camp, seize reparations, and force exile. Karma +1.", "story_twist_mercy")
        st.session_state.screen = "guild"
        st.rerun()
    if c2.button("Execution: Return stolen gold", use_container_width=True):
        p.rep += 18
        p.gold += 180
        p.gain_xp(340)
        p.quests_done += 1
        st.session_state.special_state = "done"
        chronicle("You execute the bandits and return the stolen money to Orin.", "story_twist_execute")
        st.session_state.screen = "guild"
        st.rerun()
    if c3.button("High-Karma Parley", use_container_width=True, disabled=p.karma < 8):
        p.add_karma(1)
        p.rep += 30
        p.gold += 180
        p.gain_xp(360)
        p.quests_done += 1
        st.session_state.special_state = "done"
        chronicle("Your high karma opens parley: the camp disbands into supervised labor.", "story_twist_parley")
        st.session_state.screen = "guild"
        st.rerun()


def render_missions() -> None:
    p = st.session_state.player
    render_top_bar()
    st.markdown(
        '<div class="rpg-panel"><div class="rpg-title" style="font-size:1.2rem;">Mission Board</div>'
        '<span class="rpg-kv">Pick a contract. Harder work pays better.</span></div>',
        unsafe_allow_html=True,
    )
    qs = available_quests(p, st.session_state.cooldowns)
    if not qs:
        st.info("No missions available.")
    cols = st.columns(2)
    for idx, q in enumerate(qs):
        col = cols[idx % 2]
        weak_text = ""
        if "enemy" in q:
            weak = ENEMIES.get(q["enemy"], {}).get("weak", [])
            if weak:
                weak_text = f"Weak: {', '.join(weak)}"
        with col:
            if q["type"] == "Special":
                st.markdown(
                    f'<div class="rpg-quest-card"><span class="rpg-badge">Special</span><span class="rpg-badge">Lv 5+</span>'
                    f'<div class="rpg-kv"><strong>{q["name"]}</strong></div>'
                    '<div class="mission-meta">Guildmaster Orin requests Black-Banner Camp clearance.</div></div>',
                    unsafe_allow_html=True,
                )
                if st.button("Start Special Quest", key="q-special", use_container_width=True):
                    if st.session_state.special_state == "offered":
                        st.session_state.special_state = "active"
                        st.session_state.special_round = 1
                        chronicle("You accept Orin's order to clear Black-Banner Camp.", "story_special_accept")
                    st.session_state.screen = "special_request"
                    st.rerun()
                continue

            karma_badge = f'<span class="rpg-badge">Karma {q["karma_tag"]}</span>' if "karma_tag" in q else ""
            weak_block = f'<div class="mission-meta">{weak_text}</div>' if weak_text else ""
            st.markdown(
                f'<div class="rpg-quest-card"><span class="rpg-badge">{q["type"]}</span>'
                f'<span class="rpg-badge">{q["min"]}-Rank+</span>'
                f'{karma_badge}'
                f'<div class="rpg-kv"><strong>{q["name"]}</strong></div>'
                f'<div class="mission-meta">XP {q["xp"]} | Gold {q["gold"]} | Rep {q["rep"]}</div>'
                f'{weak_block}'
                '</div>',
                unsafe_allow_html=True,
            )
            if st.button("Accept Quest", key=f"q-{q['name']}", use_container_width=True):
                st.session_state.selected_quest = q
                if q["type"] in ["Combat", "Escort"]:
                    if q["type"] == "Escort" and p.class_name == "Mage" and p.subclass_name == "Necromancer":
                        apply_quest_outcome(q, False)
                    else:
                        start_combat(q["enemy"])
                elif q["type"] == "Gathering":
                    run_noncombat_quest(q)
                elif q["type"] == "Investigation":
                    st.session_state.screen = "investigation"
                st.rerun()
    if st.button("Back", use_container_width=True):
        st.session_state.screen = "guild"
        st.rerun()


def render_investigation() -> None:
    q = st.session_state.selected_quest
    render_top_bar()
    st.write("Whispers fill the ruined chapel.")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Go Deeper", use_container_width=True):
            start_combat(q["enemy"])
            st.rerun()
    with c2:
        if st.button("Observe And Report", use_container_width=True):
            run_noncombat_quest(q, "observe")
            st.session_state.screen = "missions"
            st.rerun()


def render_shop() -> None:
    p = st.session_state.player
    render_top_bar()
    st.write("Shop")
    for k, d in ITEMS.items():
        if st.button(f"Buy {k} ({d['price']}g)", key=f"buy-{k}", help=item_tooltip(k)):
            if p.gold < d["price"]:
                push("Not enough gold.")
            else:
                p.gold -= d["price"]
                p.items[k] = p.items.get(k, 0) + 1
                push(f"Bought {k}.")
            st.rerun()
    if st.button("Back"):
        st.session_state.screen = "guild"
        st.rerun()


def render_class_mentor() -> None:
    p = st.session_state.player
    p.novice_training = max(0, min(20, p.novice_training))
    p.proficient_training = max(0, min(8, p.proficient_training))
    render_top_bar()
    st.write("Mentor Hall")
    st.markdown(
        '<div class="rpg-grid-card"><span class="rpg-kv"><strong>Class Tree</strong><br>'
        'Root (Lv3): Swordsman / Mage / Third Path (placeholder)<br>'
        'Mage (Lv20): Elementalist or Necromancer</span></div>',
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    swords_lock = p.level < 3 and not p.class_name
    mage_lock = p.level < 3 and not p.class_name
    with c1:
        st.caption("Swordsman")
        st.caption("Status: LOCKED" if swords_lock else ("Chosen" if p.class_name == "Swordsman" else "Available"))
        if st.button("Choose Swordsman", use_container_width=True, disabled=swords_lock or p.class_name is not None):
            p.choose_class("Swordsman")
            push("Class chosen: Swordsman. Bleed sword arts unlocked by level.")
            st.rerun()
    with c2:
        st.caption("Mage")
        st.caption("Status: LOCKED" if mage_lock else ("Chosen" if p.class_name == "Mage" else "Available"))
        if st.button("Choose Mage", use_container_width=True, disabled=mage_lock or p.class_name is not None):
            p.choose_class("Mage")
            push("Class chosen: Mage. Train novice spells now; choose branch at level 20.")
            st.rerun()
    with c3:
        st.caption("Third Path")
        st.caption("Status: LOCKED (placeholder)")
        st.button("Choose Third Path", use_container_width=True, disabled=True)

    if p.class_name == "Swordsman":
        st.markdown(
            f'<div class="rpg-grid-card"><span class="rpg-kv"><strong>Swordsman Path</strong><br>'
            f'Crit Chance: {int(p.crit_chance() * 100)}% | Bleed affects flesh enemies only.</span></div>',
            unsafe_allow_html=True,
        )
        st.write("Unlocked/Upcoming Abilities")
        for lvl, skills in CLASS_DATA["Swordsman"]["skills"].items():
            for s in skills:
                state = "Unlocked" if p.level >= lvl else f"Locked (Lv {lvl})"
                st.caption(f"{s['name']} | {state}")
    elif p.class_name == "Mage":
        st.markdown(
            f'<div class="rpg-grid-card"><span class="rpg-kv"><strong>Mage Path</strong> | '
            f'Novice Training: {p.novice_training}/20 | Advanced Training: {p.proficient_training}/8 | '
            f'Branch: {p.subclass_name or "Locked until Lv20"}</span></div>',
            unsafe_allow_html=True,
        )

        if p.level >= 20 and not p.subclass_name:
            st.write("Choose Advanced Mage Branch")
            b1, b2 = st.columns(2)
            if b1.button("Elementalist", use_container_width=True):
                if p.choose_subclass("Elementalist"):
                    push("Advanced branch chosen: Elementalist.")
                st.rerun()
            if b2.button("Necromancer", use_container_width=True):
                if p.choose_subclass("Necromancer"):
                    push("Advanced branch chosen: Necromancer.")
                st.rerun()
        elif p.level < 20:
            st.caption("Advanced branch unlocks at level 20.")

        t1, t2 = st.columns(2)
        with t1:
            if st.button("Train Novice (50g)", use_container_width=True):
                if p.train_novice():
                    push(f"Training complete. Sessions {p.novice_training}/20.")
                else:
                    novice_left = [
                        s for s in NOVICE_SKILLS.get("Mage", [])
                        if not any(k["name"] == s["name"] for k in p.skills)
                    ]
                    if not novice_left:
                        push("All novice spells are already learned. No more novice training needed.")
                    elif p.novice_training >= 20:
                        push("Novice training is full at 20/20. Learn a spell to spend points.")
                    else:
                        push("Not enough gold for novice lesson.")
                st.rerun()
        with t2:
            if st.button("Train Advanced (90g)", use_container_width=True):
                if p.train_proficient():
                    push(f"Advanced lesson done. Sessions {p.proficient_training}/8.")
                else:
                    adv_left = [s for s in PROFICIENT_SKILLS.get(p.subclass_name or "", []) if not any(k["name"] == s["name"] for k in p.skills)]
                    if not p.subclass_name:
                        push("Choose an advanced branch at level 20 first.")
                    elif p.level < 20:
                        push("Need level 20+ for advanced lessons.")
                    elif not adv_left:
                        push("All advanced spells are already learned. No more advanced training needed.")
                    elif p.proficient_training >= 8:
                        push("Advanced training is full at 8/8. Learn a spell to spend points.")
                    else:
                        push("Not enough gold for advanced lesson.")
                st.rerun()

        st.write("Mage Novice Spells (10)")
        novice_list = [s for s in NOVICE_SKILLS.get("Mage", []) if not any(k["name"] == s["name"] for k in p.skills)]
        for idx, s in enumerate(novice_list):
            label = f"{s['name']} | {s['element']} | MP {s['mp']} | ~{p.estimated_skill_damage(s)} dmg"
            if st.button(label, key=f"learn-nov-{idx}", disabled=p.novice_training < 20):
                if p.learn_novice_spell(s["name"]):
                    push(f"Learned {s['name']}. Spent 20 novice training points.")
                st.rerun()

        if p.subclass_name:
            st.write(f"{p.subclass_name} Spells (10)")
            adv_list = [s for s in PROFICIENT_SKILLS[p.subclass_name] if not any(k["name"] == s["name"] for k in p.skills)]
            for idx, s in enumerate(adv_list):
                label = f"{s['name']} | {s['element']} | MP {s['mp']} | ~{p.estimated_skill_damage(s)} dmg"
                if st.button(label, key=f"learn-adv-{idx}", disabled=p.proficient_training < 8):
                    if p.learn_proficient_spell(s["name"]):
                        push(f"Learned {s['name']}. Spent 8 advanced training points.")
                    st.rerun()
    if st.button("Back"):
        st.session_state.screen = "guild"
        st.rerun()


def render_inventory() -> None:
    p = st.session_state.player
    render_top_bar()
    head_left, head_right = st.columns([3, 1])
    with head_left:
        st.write("Inventory")
    with head_right:
        if st.button("Back", key="inv-back-top", use_container_width=True):
            st.session_state.screen = "main"
            st.rerun()
    if not p.items:
        st.info("Inventory is empty.")
    for k, v in p.items.items():
        st.markdown(
            f'<span title="{item_tooltip(k)}">{k} x{v}</span>',
            unsafe_allow_html=True,
        )
    st.write("Use Consumable")
    consumables = [k for k, q in p.items.items() if q > 0 and ITEMS.get(k, {}).get("t") == "con"]
    for it in consumables:
        if st.button(f"Use {it}", key=f"use-{it}", help=item_tooltip(it)):
            use_consumable(it)
            st.rerun()
    st.write("Equip")
    equipables = [k for k, q in p.items.items() if q > 0 and ITEMS.get(k, {}).get("t") == "eq"]
    for it in equipables:
        slot = ITEMS[it]["slot"]
        if st.button(f"Equip {it} ({slot})", key=f"eq-{it}", help=item_tooltip(it)):
            equip_item(it)
            st.rerun()
    st.write("Equipped Gear")
    for slot in ["weapon", "armor"]:
        equipped = p.equip.get(slot)
        if equipped:
            if st.button(f"Unequip {equipped} ({slot})", key=f"uneq-{slot}", help=item_tooltip(equipped)):
                unequip_item(slot)
                st.rerun()
        else:
            st.caption(f"{slot.title()}: none")
    if st.button("Back", key="inv-back-bottom"):
        st.session_state.screen = "main"
        st.rerun()


def render_character() -> None:
    p = st.session_state.player
    render_top_bar()
    st.write("Character")
    st.write(f"XP: {p.exp}/{p.need_xp()} | Total XP: {p.total_xp()}")
    st.write(f"STR {p.stats.str} | INT {p.stats.int} | DEF {p.stats.defn} | AGI {p.stats.agi}")
    st.write(f"Karma: {p.karma}/10")
    st.write(f"Path: {p.path_choice or 'None'}")
    if p.class_name == "Swordsman":
        st.write(f"Crit Chance: {int(p.crit_chance() * 100)}%")
    if p.subclass_name:
        st.write(f"Mage Branch: {p.subclass_name}")
    if p.class_name in NOVICE_SKILLS:
        st.write(f"Novice training sessions: {p.novice_training}/20")
    if p.skills:
        st.write("Skills")
        for s in p.skills:
            st.write(f"- {s['name']} ({s.get('element', 'neutral')}, MP {s['mp']}) ~{p.estimated_skill_damage(s)} dmg")
    else:
        st.write("Skills: None")
    if st.button("Back"):
        st.session_state.screen = "main"
        st.rerun()


def render_combat() -> None:
    p = st.session_state.player
    c = st.session_state.combat
    render_top_bar()
    st.error(f"Combat: {p.name} vs {c['enemy_name']}")
    weak = c["enemy"].get("weak", [])
    weak_line = f" | Weakness: {', '.join(weak)}" if weak else ""
    st.write(f"{c['enemy_name']} HP: {c['ehp']}/{c['enemy']['hp']}{weak_line}")
    if c.get("skeleton_guard_hp", 0) > 0:
        st.caption(f"Skeleton Guard HP: {c['skeleton_guard_hp']}/50")

    if c["status"] in ["won", "lost", "fled"]:
        src = c.get("source", "mission")
        if src == "special_wave":
            if c["status"] == "won":
                st.session_state.special_round += 1
                if st.session_state.special_round > 5:
                    st.session_state.special_state = "twist"
                    chronicle("All five lieutenants fall. The command tent holds a darker truth.", "story_special_clear")
                    next_screen = "special_twist"
                else:
                    next_screen = "special_request"
            else:
                next_screen = "special_request"
                push("You are forced to retreat from Black-Banner Camp.")
        elif src == "assassin":
            next_screen = "main"
        elif src == "npc":
            next_screen = "npcs"
        else:
            q = st.session_state.selected_quest
            if q is not None:
                apply_quest_outcome(q, c["status"] == "won")
                st.session_state.selected_quest = None
            next_screen = "missions"
        if st.button("Return"):
            st.session_state.screen = next_screen
            st.session_state.combat = None
            st.rerun()
        return

    c1, c2, c3, c4, c5 = st.columns(5)
    if c1.button("Attack", use_container_width=True):
        combat_action_attack()
        st.rerun()
    if c2.button("Defend", use_container_width=True):
        combat_action_defend()
        st.rerun()
    if c3.button("Flee", use_container_width=True):
        combat_action_flee()
        st.rerun()

    if c4.button("Skill", use_container_width=True):
        st.session_state.screen = "skill_pick"
        st.rerun()

    if c5.button("Item", use_container_width=True):
        st.session_state.screen = "item_pick"
        st.rerun()


def render_skill_pick() -> None:
    p = st.session_state.player
    c = st.session_state.combat
    render_top_bar()
    st.write("Choose a skill")
    if not p.skills:
        st.info("No skills yet.")
    for i, s in enumerate(p.skills):
        est = p.estimated_skill_damage(s)
        if st.button(f"{s['name']} ({s.get('element', 'neutral')}) MP {s['mp']} ~{est} dmg", key=f"skill-{i}"):
            apply_enemy_dot()
            if finish_combat_if_done():
                st.session_state.screen = "combat"
                st.rerun()
            if p.mp < s["mp"]:
                push("Not enough MP.")
            else:
                p.mp -= s["mp"]
                stat = p.stats.int if p.class_name == "Mage" else p.stats.str
                if s["kind"] == "buff":
                    p.guard += 5
                    d = 0
                    push("Defense boosted.")
                elif s["kind"] == "skeleton_guard":
                    c["skeleton_guard_hp"] = 50
                    d = 0
                    push("Skeleton guard rises to shield you.")
                else:
                    d = Combat.dmg(stat, c["enemy"]["def"], s["pow"])
                    if p.class_name == "Swordsman" and s["kind"] == "sword_bleed" and random.random() < p.crit_chance():
                        d *= 2
                        push("Critical hit!")
                    if Combat.elemental_multiplier(c["enemy"], s) > 1.0:
                        d = int(d * Combat.elemental_multiplier(c["enemy"], s))
                        push("Elemental weakness exploited!")
                    c["ehp"] = max(0, c["ehp"] - d)
                    push(f"{s['name']} deals {d}.")
                if s["kind"] == "sword_bleed" and c["enemy"].get("flesh", False):
                    if random.random() < s.get("bleed_chance", 0.7):
                        c["bleed_turns"] = max(c.get("bleed_turns", 0), s.get("bleed_turns", 2))
                        c["bleed_dmg"] = max(c.get("bleed_dmg", 0), max(3, int(d * 0.22)))
                        push("Bleed inflicted.")
                if s["kind"] == "poison":
                    c["poison_turns"] = max(c.get("poison_turns", 0), 3)
                    c["poison_dmg"] = max(c.get("poison_dmg", 0), max(4, int(d * 0.2)))
                    push("Poison applied.")
                if s["kind"] == "soul_stun" and random.random() < 0.9:
                    c["stun_turns"] = max(c.get("stun_turns", 0), 1)
                    push("Soul lock! Enemy is stunned.")
                if s["kind"] == "drain":
                    h = max(1, int(d * 0.1))
                    p.hp = min(p.stats.max_hp, p.hp + h)
                    push(f"Drain heals {h}.")
                if s["kind"] == "summon":
                    b = random.randint(4, 12)
                    c["ehp"] = max(0, c["ehp"] - b)
                    push(f"Skeleton hits for {b}.")
                if not finish_combat_if_done():
                    enemy_turn()
                    finish_combat_if_done()
            st.session_state.screen = "combat"
            st.rerun()
    if st.button("Back"):
        st.session_state.screen = "combat"
        st.rerun()


def render_item_pick() -> None:
    p = st.session_state.player
    render_top_bar()
    st.write("Use item")
    con = [k for k, q in p.items.items() if q > 0 and ITEMS.get(k, {}).get("t") == "con"]
    if not con:
        st.info("No consumables.")
    for it in con:
        if st.button(f"{it} x{p.items[it]}", key=f"combat-item-{it}", help=item_tooltip(it)):
            apply_enemy_dot()
            if finish_combat_if_done():
                st.session_state.screen = "combat"
                st.rerun()
            use_consumable(it)
            enemy_turn()
            finish_combat_if_done()
            st.session_state.screen = "combat"
            st.rerun()
    if st.button("Back"):
        st.session_state.screen = "combat"
        st.rerun()


def main() -> None:
    st.set_page_config(page_title="RPG Text Web", layout="wide")
    inject_styles()
    init_state()

    screen = st.session_state.screen
    set_scroll_mode(True)
    if screen == "start":
        render_start()
    elif screen == "intro":
        render_intro()
    elif screen == "main":
        render_main()
    elif screen == "npcs":
        render_npc_hall()
    elif screen == "guild":
        render_guild()
    elif screen == "missions":
        render_missions()
    elif screen == "special_request":
        render_special_request()
    elif screen == "special_twist":
        render_special_twist()
    elif screen == "investigation":
        render_investigation()
    elif screen == "shop":
        render_shop()
    elif screen == "class":
        render_class_mentor()
    elif screen == "inventory":
        render_inventory()
    elif screen == "character":
        render_character()
    elif screen == "journal":
        render_journal()
    elif screen == "combat":
        render_combat()
    elif screen == "skill_pick":
        render_skill_pick()
    elif screen == "item_pick":
        render_item_pick()

if __name__ == "__main__":
    main()
